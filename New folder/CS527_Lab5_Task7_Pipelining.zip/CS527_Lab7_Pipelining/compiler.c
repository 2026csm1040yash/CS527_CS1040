#include "compiler.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 512
#define MAX_LINE 512

typedef struct {
    char label[64];
    int instruction_index;
} Label;

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) --end;
    *end = '\0';
    return s;
}

static void strip_comment(char *s) {
    char *p = strchr(s, '%');
    if (p) *p = '\0';
}

static int reg_int(const char *s) {
    if (s[0] != 'x' || !isdigit((unsigned char)s[1])) return -1;
    char *end;
    long n = strtol(s + 1, &end, 10);
    if (*end || n < 0 || n > 255) return -1;
    return (int)n;
}

static int reg_vec(const char *s) {
    if (s[0] != 'v' || !isdigit((unsigned char)s[1])) return -1;
    char *end;
    long n = strtol(s + 1, &end, 10);
    if (*end || n < 0 || n > 31) return -1;
    return (int)n;
}

static int constant_value(const char *s) {
    char *end;
    long n;
    if (s[0] == '#') s++;
    n = strtol(s, &end, 0);
    if (*s == '\0' || *end || n < 0 || n > 255) return -1;
    return (int)n;
}

static void normalize(char *s) {
    for (char *p = s; *p; ++p) {
        if (*p == ',' || *p == ';' || *p == '[' || *p == ']')
            *p = ' ';
    }
}

static int tokenize(char *s, char *tok[], int max_tok) {
    int n = 0;
    char *p = strtok(s, " \t\r\n");
    while (p && n < max_tok) {
        tok[n++] = p;
        p = strtok(NULL, " \t\r\n");
    }
    return n;
}

static int is_label(const char *s) {
    return s[0] == '.';
}

static int find_label(Label labels[], int count, const char *name) {
    for (int i = 0; i < count; ++i)
        if (strcmp(labels[i].label, name) == 0) return labels[i].instruction_index;
    return -1;
}

static int emit(FILE *out, unsigned a, unsigned b, unsigned c, unsigned d) {
    if (a > 255 || b > 255 || c > 255 || d > 255) return -1;
    fprintf(out, "%02X %02X %02X %02X\n", a, b, c, d);
    return 0;
}

static int compile_line(char *line, int index, Label labels[], int nlabels, FILE *out) {
    char original[MAX_LINE];
    char work[MAX_LINE];
    char *tok[8];
    int nt;

    strncpy(original, line, sizeof(original)-1);
    original[sizeof(original)-1] = '\0';

    /* Handle memory operations before normalizing brackets. */
    if (strchr(original, '[') && strchr(original, ']') && strchr(original, '=')) {
        char raw[MAX_LINE];
        strncpy(raw, original, sizeof(raw)-1);
        raw[sizeof(raw)-1] = '\0';

        char *eq = strchr(raw, '=');
        *eq = '\0';
        char *lhs = trim(raw);
        char *rhs = trim(eq + 1);

        if (lhs[0] != '[') {
            /* memory read: xD = [address] */
            int dst_i = reg_int(lhs);
            int dst_v = reg_vec(lhs);
            if (dst_i < 0 && dst_v < 0) return -1;

            if (rhs[0] != '[') return -1;
            rhs++; /* skip '[' */
            char *close = strchr(rhs, ']');
            if (!close) return -1;
            *close = '\0';
            rhs = trim(rhs);

            int ar = reg_int(rhs);
            int ac = constant_value(rhs);

            if (dst_i >= 0) {
                if (ar >= 0) return emit(out, 0x05, dst_i, 0, ar);
                if (ac >= 0) return emit(out, 0x0D, dst_i, 0, ac);
            } else {
                if (ar >= 0) return emit(out, 0x25, dst_v, 0, ar);
                if (ac >= 0) return emit(out, 0x2C, dst_v, 0, ac);
            }
            return -1;
        } else {
            /* memory write: [address] = source */
            lhs++;
            char *close = strchr(lhs, ']');
            if (!close) return -1;
            *close = '\0';
            lhs = trim(lhs);

            int ar = reg_int(lhs);
            int ac = constant_value(lhs);
            int sr = reg_int(rhs);
            int sv = reg_vec(rhs);

            if (sr >= 0) {
                if (ar >= 0) return emit(out, 0x06, 0, ar, sr);
                if (ac >= 0) return emit(out, 0x0E, 0, ac, sr);
            }
            if (sv >= 0) {
                if (ar >= 0) return emit(out, 0x26, 0, ar, sv);
                if (ac >= 0) return emit(out, 0x2E, 0, ac, sv);
            }
            return -1;
        }
    }

    strncpy(work, original, sizeof(work)-1);
    work[sizeof(work)-1] = '\0';
    normalize(work);
    nt = tokenize(work, tok, 8);
    if (nt == 0) return 0;

    /* Legacy Lab 1 syntax: Read <register> <constant-address> and
       Write <register> <constant-address>. Lab 2+ uses bracket syntax,
       but the specification requires the compiler to retain legacy support. */
    if (strcmp(tok[0], "Read") == 0 || strcmp(tok[0], "read") == 0) {
        if (nt != 3) return -1;
        int d = reg_int(tok[1]);
        int a = constant_value(tok[2]);
        if (d < 0 || a < 0) return -1;
        return emit(out, 0x0D, (unsigned)d, 0, (unsigned)a);
    }
    if (strcmp(tok[0], "Write") == 0 || strcmp(tok[0], "write") == 0) {
        if (nt != 3) return -1;
        int sreg = reg_int(tok[1]);
        int a = constant_value(tok[2]);
        if (sreg < 0 || a < 0) return -1;
        return emit(out, 0x0E, 0, (unsigned)a, (unsigned)sreg);
    }

    if (strcmp(tok[0], "print") == 0 || strcmp(tok[0], "Print") == 0) {
        if (nt != 2) return -1;
        int r = reg_int(tok[1]);
        if (r < 0) return -1;
        return emit(out, 0x08, 0, 0, (unsigned)r);
    }

    if (tok[0][0] == 'B' && tok[0][1] != '\0') {
        unsigned code = 255;
        const char *suf = tok[0] + 1;
        const char *names[] = {"EQ","NE","CS","CC","MI","PL","VS","VC","HI","LS","GE","LT","GT","LE","AL"};
        for (unsigned i = 0; i < 15; ++i)
            if (strcmp(suf, names[i]) == 0) { code = i; break; }
        if (code == 255 || nt != 2) return -1;

        int target = find_label(labels, nlabels, tok[1]);
        if (target < 0) return -1;
        int target_addr = target * 4;
        int current_addr = index * 4;
        int offset = target_addr - current_addr;
        if (offset < -128 || offset > 127) return -1;
        return emit(out, 0x10 + code, 0, 0, (unsigned char)offset);
    }

    if (nt >= 3 && strcmp(tok[1], "=") == 0) {
        int dst_i = reg_int(tok[0]);
        int dst_v = reg_vec(tok[0]);

        if (nt == 3) {
            int val = constant_value(tok[2]);
            if (dst_i < 0 || val < 0) return -1;
            return emit(out, 0x0F, (unsigned)dst_i, 0, (unsigned)val);
        }

        if (nt != 5) return -1;

        const char *op = tok[3];

        if (dst_v >= 0) {
            int src_v = reg_vec(tok[2]);
            if (src_v < 0) return -1;

            int bvec = reg_vec(tok[4]);
            int bint = reg_int(tok[4]);
            int bc = constant_value(tok[4]);

            if (bvec >= 0) {
                if (strcmp(op, "+") == 0) return emit(out, 0x21, dst_v, src_v, bvec);
                if (strcmp(op, "-") == 0) return emit(out, 0x22, dst_v, src_v, bvec);
                if (strcmp(op, "*") == 0) return emit(out, 0x23, dst_v, src_v, bvec);
            } else {
                int value = (bint >= 0) ? bint : bc;
                if (value < 0) return -1;
                if (strcmp(op, "+") == 0) return emit(out, 0x29, dst_v, src_v, value);
                if (strcmp(op, "-") == 0) return emit(out, 0x2A, dst_v, src_v, value);
                if (strcmp(op, "*") == 0) return emit(out, 0x2B, dst_v, src_v, value);
            }
        }

        if (dst_i >= 0) {
            int src_i = reg_int(tok[2]);
            if (src_i < 0) return -1;
            int bint = reg_int(tok[4]);
            int bc = constant_value(tok[4]);

            if (bint >= 0) {
                if (strcmp(op, "+") == 0) return emit(out, 0x01, dst_i, src_i, bint);
                if (strcmp(op, "-") == 0) return emit(out, 0x02, dst_i, src_i, bint);
                if (strcmp(op, "*") == 0) return emit(out, 0x03, dst_i, src_i, bint);
                if (strcmp(op, "/") == 0) return emit(out, 0x04, dst_i, src_i, bint);
            } else if (bc >= 0) {
                if (strcmp(op, "+") == 0) return emit(out, 0x09, dst_i, src_i, bc);
                if (strcmp(op, "-") == 0) return emit(out, 0x0A, dst_i, src_i, bc);
                if (strcmp(op, "*") == 0) return emit(out, 0x0B, dst_i, src_i, bc);
                if (strcmp(op, "/") == 0) return emit(out, 0x0C, dst_i, src_i, bc);
            }
        }
    }

    return -1;
}

int compile_program(const char *source_file, const char *program_byte_file) {
    FILE *in = fopen(source_file, "r");
    if (!in) { perror(source_file); return -1; }

    char lines[MAX_LINES][MAX_LINE];
    int count = 0;
    while (count < MAX_LINES && fgets(lines[count], MAX_LINE, in)) {
        strip_comment(lines[count]);
        char tmp[MAX_LINE];
        strncpy(tmp, lines[count], MAX_LINE-1); tmp[MAX_LINE-1]='\0';
        char *s = trim(tmp);
        if (*s) {
            strncpy(lines[count], s, MAX_LINE-1); lines[count][MAX_LINE-1]='\0';
            count++;
        }
    }
    fclose(in);

    Label labels[128];
    int nlabels = 0, instruction_index = 0;
    for (int i=0; i<count; ++i) {
        char tmp[MAX_LINE];
        strncpy(tmp, lines[i], MAX_LINE-1); tmp[MAX_LINE-1]='\0';
        char *s = trim(tmp);
        if (is_label(s)) {
            if (nlabels >= 128 || strlen(s) >= sizeof(labels[0].label)) return -1;
            strcpy(labels[nlabels].label, s);
            labels[nlabels].instruction_index = instruction_index;
            nlabels++;
        } else {
            instruction_index++;
        }
    }

    FILE *out = fopen(program_byte_file, "w");
    if (!out) { perror(program_byte_file); return -1; }

    instruction_index = 0;
    for (int i=0; i<count; ++i) {
        char *s = trim(lines[i]);
        if (is_label(s)) continue;
        if (compile_line(s, instruction_index, labels, nlabels, out) != 0) {
            fprintf(stderr, "Compiler error in %s line %d: %s\n", source_file, i+1, s);
            fclose(out);
            return -1;
        }
        instruction_index++;
    }

    /* opcode 0 terminates execution */
    emit(out, 0, 0, 0, 0);
    fclose(out);
    return 0;
}

int copy_data_file(const char *source_data_file, const char *data_byte_file) {
    FILE *in = fopen(source_data_file, "r");
    if (!in) { perror(source_data_file); return -1; }
    FILE *out = fopen(data_byte_file, "w");
    if (!out) { perror(data_byte_file); fclose(in); return -1; }

    char line[512];
    while (fgets(line, sizeof(line), in)) {
        char *p = line;
        while (*p) {
            if (*p == '%') { *p = '\0'; break; }
            p++;
        }
        char *tok = strtok(line, " \t\r\n");
        while (tok) {
            unsigned long v = strtoul(tok, NULL, 16);
            if (v > 255) {
                fprintf(stderr, "Invalid data byte: %s\n", tok);
                fclose(in); fclose(out); return -1;
            }
            fprintf(out, "%02lX", v);
            tok = strtok(NULL, " \t\r\n");
            if (tok) fputc(' ', out);
        }
        fputc('\n', out);
    }
    fclose(in);
    fclose(out);
    return 0;
}
