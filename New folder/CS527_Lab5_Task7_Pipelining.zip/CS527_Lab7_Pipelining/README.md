# CS527 Lab 5 - Task 6: Cache + TLB + Timing

## Objective
Extend the existing CS527 mini-computer with a processor-side TLB and cache, and add timing/statistics so the impact can be observed.

The implementation remains compatible with the Lab 5 architecture: 32-bit integer registers, vector registers, paged logical/physical memory, and processor-side logical-to-physical translation.

## Task 6 implementation

### TLB
- 4-entry processor-side TLB.
- Each entry stores: PID, logical page number, physical frame number, valid bit, and replacement age.
- TLB is checked before reading the page table in physical memory.
- TLB is invalidated for a processor when a new process is loaded there.

### Cache
- 8-line direct-mapped cache.
- 16 bytes per cache line.
- Physical addresses are cached after address translation.
- Write-through policy: writes update both cache and physical memory.
- Instruction fetches and data accesses use the same cache array but have separate instruction/data hit/miss counters.

### Timing model
The simulator uses an explicit, documented cycle model:
- Base instruction: 1 cycle
- TLB hit: 1 cycle
- TLB miss/page-table lookup: 10 cycles
- Cache hit: 1 cycle
- Cache miss/refill: 20 cycles
- MMIO access: 5 cycles

These are simulator timing assumptions for measuring relative impact; they are not claimed as hardware timings from the lab handout.

## Useful commands

Build on Linux:
```bash
make
```

Build on Windows/MinGW:
```powershell
.\build_windows.bat
```

Run the Task 6 timing comparison:
```bash
./tests/run_task6_timing.sh
```

Windows:
```powershell
.\tests\run_task6_timing.bat
```

With cache + TLB:
```bash
./cs527_lab --timing tests/cache_tlb_test.txt tests/cache_tlb_test.data
```

Baseline without cache + TLB:
```bash
./cs527_lab --no-cache-tlb --timing tests/cache_tlb_test.txt tests/cache_tlb_test.data
```

## Example interpretation

The cache/TLB version should report non-zero TLB hits/misses and cache hits/misses and a larger simulated cycle count under the timing model. The baseline disables both structures, allowing the cycle/statistics difference to be discussed as the impact of adding the structures.

## Expected test behavior

The test repeatedly reads the same data address and writes the result back. This creates repeated translations and repeated physical-memory accesses, making TLB/cache behavior visible.

Example statistics from the included test on the reference build:

With cache + TLB:
```
PID    CPU    Cycles       TLBHit     TLBMiss    CacheHit CacheMiss  MemRead    MemWrite
1      0      285          48         2          48       8          4          1
```

Without cache + TLB:
```
PID    CPU    Cycles       TLBHit     TLBMiss    CacheHit CacheMiss  MemRead    MemWrite
1      0      9            0          0          0        0          4          1
```

Exact values can vary if the timing constants or test program are changed.
