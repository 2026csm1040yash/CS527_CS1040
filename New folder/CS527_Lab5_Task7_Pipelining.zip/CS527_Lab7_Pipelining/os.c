#include "os.h"
#include "processor.h"
#include "compiler.h"
#include "memory.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#endif
#ifdef _WIN32
#include <conio.h>
#else
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#endif

#define MAX_TASKS 32

typedef struct {
    int valid;
    int pc;
    unsigned char op, d, s1, s2;
} PipeInst;

typedef struct {
    PipeInst ifs, id, ex, mem, wb;
    int fetch_pc;
    int flush_count;
    unsigned long long pipe_cycles;
    unsigned long stalls;
    unsigned long flushes;
    unsigned long retired;
} PipeState;

static PipeState pipe_state[NP];
static void pipe_init_task(int pid);

typedef struct {
    int active;
    int pid;
    int proc_id;
    char program[256];
    char data[256];
    int page_table_frame;
    unsigned long instructions, memory_reads, memory_writes, time_slices;
    unsigned long long cycles; unsigned long tlb_hits, tlb_misses, cache_hits, cache_misses;
    unsigned long long pipeline_cycles; unsigned long pipeline_stalls; unsigned long pipeline_flushes; unsigned long pipeline_retired;
} Task;

static Task tasks[MAX_TASKS];
static int next_pid = 1;
static unsigned char free_pages[NUM_PHYSICAL_PAGES];

static int getFreePage(void) {
    for (int i=1; i<NUM_PHYSICAL_PAGES; ++i) {
        if (!free_pages[i]) {
            free_pages[i]=1;
            return i;
        }
    }
    return -1;
}

static void free_task_memory(int proc_id, int pt_frame) {
    if (pt_frame > 0 && pt_frame < NUM_PHYSICAL_PAGES) {
        unsigned char *m=physical_memory();
        int base=pt_frame*PAGESIZE;
        for(int i=0;i<NUM_LOGICAL_PAGES;i++){int frame=m[base+i]; if(frame>0&&frame<NUM_PHYSICAL_PAGES) free_pages[frame]=0; m[base+i]=0;}
        free_pages[pt_frame]=0;
    }
    processors[proc_id].page_table_frame=-1;
}

static void dump_page_table(int pid);

static int count_data_bytes(const char *file) {
    FILE *f=fopen(file,"r"); if(!f) return -1;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1) { if(x>255){fclose(f);return -1;} n++; }
    fclose(f); return n;
}

static int load_bytes_to_pages(const char *file, int proc_id, int is_instruction) {
    FILE *f=fopen(file,"r");
    if(!f) {perror(file);return -1;}
    int max = is_instruction ? INST_LOGICAL_SIZE : DATA_LOGICAL_SIZE;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1){
        if(n>=max || x>255){fclose(f);return -1;}
        int logical=n;
        int phys=getPhysicalAddress(proc_id,is_instruction,logical);
        if(phys<0){fclose(f);return -1;}
        physical_memory()[phys]=(unsigned char)x;
        n++;
    }
    fclose(f);
    return n;
}

static int write_data_file(const char *file, int proc_id) {
    int n = count_data_bytes(file);
    if (n < 0) return -1;
    FILE *out = fopen(file, "w");
    if (!out) { perror(file); return -1; }
    unsigned char *m = physical_memory();
    for (int i = 0; i < n; ++i) {
        int phys = getPhysicalAddress(proc_id, 0, i);
        if (phys < 0) { fclose(out); return -1; }
        fprintf(out, "%02X", m[phys]);
        if ((i + 1) % 4 == 0) fputc('\n', out);
        else fputc(' ', out);
    }
    if (n % 4) fputc('\n', out);
    fclose(out);
    return 0;
}

static int allocate_for_task(int proc_id,const char*program,const char*data,int*pt_out){
    int ib=count_data_bytes(program),db=count_data_bytes(data); if(ib<0||db<0)return -1;
    int ip=(ib+PAGESIZE-1)/PAGESIZE, dp=(db+PAGESIZE-1)/PAGESIZE;
    if(ip>INST_LOGICAL_SIZE/PAGESIZE||dp>DATA_LOGICAL_SIZE/PAGESIZE)return -1;
    int pt=getFreePage(); if(pt<0)return -1; processors[proc_id].page_table_frame=pt;
    unsigned char*m=physical_memory(); int base=pt*PAGESIZE; memset(m+base,0,PAGESIZE);
    for(int i=0;i<ip;i++){int f=getFreePage();if(f<0){free_task_memory(proc_id,pt);return -1;}m[base+i]=(unsigned char)f;}
    for(int i=0;i<dp;i++){int f=getFreePage();if(f<0){free_task_memory(proc_id,pt);return -1;}m[base+INST_LOGICAL_SIZE/PAGESIZE+i]=(unsigned char)f;}
    if(load_bytes_to_pages(program,proc_id,1)<0||load_bytes_to_pages(data,proc_id,0)<0){free_task_memory(proc_id,pt);return -1;}
    *pt_out=pt; return 0;
}

void os_init(void) {
    memset(tasks,0,sizeof(tasks));
    memset(free_pages,0,sizeof(free_pages));
    memory_reset();
    for(int p=0;p<NP;p++){
        memset(&processors[p],0,sizeof(processors[p]));
        processors[p].proc_id=p; processors[p].page_table_frame=-1;
        snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/process%d.log",p);
    }
#ifdef _WIN32
    _mkdir("logs");
#else
    mkdir("logs", 0755);
#endif
}

int os_add_task(const char *program_file, const char *data_file) {
    int slot=-1;
    for(int i=0;i<NP;i++) if(!processors[i].used){slot=i;break;}

    int t=-1;
    for(int i=0;i<MAX_TASKS;i++) if(!tasks[i].active){t=i;break;}
    if(t<0) return -1;

    if(slot<0) {
        /* Four processors are busy: retain the task in the waiting queue.
           It will be loaded when a processor becomes free. */
        tasks[t].active=1;
        tasks[t].pid=next_pid++;
        tasks[t].proc_id=-1;
        strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
        strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);
        printf("PID %d placed in waiting queue.\n",tasks[t].pid);
        return tasks[t].pid;
    }

    tasks[t].active=1;
    tasks[t].pid=next_pid++;
    tasks[t].proc_id=slot;
    strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
    strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);

    processors[slot].used=1;
    processors[slot].proc_id=slot;
    int pt_frame=-1;
    if(allocate_for_task(slot,program_file,data_file,&pt_frame)!=0){
        processors[slot].used=0; tasks[t].active=0; return -1;
    }
    tasks[t].page_table_frame=pt_frame;
    snprintf(processors[slot].log_file,sizeof(processors[slot].log_file),"logs/pid%d.log",tasks[t].pid);
    processor_reset(slot);
    printf("Loaded PID %d on processor %d.\n",tasks[t].pid,slot);
    dump_page_table(slot);
    return tasks[t].pid;
}

static int active_count(void) {
    int n=0;
    for(int i=0;i<MAX_TASKS;i++) if(tasks[i].active)n++;
    return n;
}

static void release_finished(void) {
    for(int i=0;i<MAX_TASKS;i++){
        if(tasks[i].active && tasks[i].proc_id>=0){
            int p=tasks[i].proc_id;
            if(processors[p].finished){
                printf("PID %d finished on processor %d.\n",tasks[i].pid,p);
                tasks[i].instructions=processors[p].instructions_executed;
                tasks[i].memory_reads=processors[p].memory_reads;
                tasks[i].memory_writes=processors[p].memory_writes;
                tasks[i].time_slices=processors[p].time_slices;
                tasks[i].cycles=processors[p].cycles; tasks[i].pipeline_cycles=pipe_state[p].pipe_cycles; tasks[i].pipeline_stalls=pipe_state[p].stalls; tasks[i].pipeline_flushes=pipe_state[p].flushes; tasks[i].pipeline_retired=pipe_state[p].retired; tasks[i].tlb_hits=processors[p].tlb_hits; tasks[i].tlb_misses=processors[p].tlb_misses; tasks[i].cache_hits=processors[p].cache_hits; tasks[i].cache_misses=processors[p].cache_misses;
                write_data_file(tasks[i].data,p);
                free_task_memory(p,tasks[i].page_table_frame);
                processors[p].used=0;
                tasks[i].active=0;
            }
        }
    }

    /* Fill newly free processors from the waiting queue. */
    for(int p=0;p<NP;p++){
        if(processors[p].used) continue;
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id==-1){
                tasks[i].proc_id=p;
                processors[p].used=1;
                int pt_frame=-1;
                if(allocate_for_task(p,tasks[i].program,tasks[i].data,&pt_frame)!=0){
                    tasks[i].active=0; processors[p].used=0;
                    continue;
                }
                tasks[i].page_table_frame=pt_frame;
                snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/pid%d.log",tasks[i].pid);
                processor_reset(p);
                pipe_init_task(p);
                printf("Loaded waiting PID %d on processor %d.\n",tasks[i].pid,p);
                dump_page_table(p);
                break;
            }
        }
    }
}

static void dump_page_table(int pid){
    int pt=processors[pid].page_table_frame; unsigned char*m=physical_memory();
    printf("  Page table: physical frame %d (physical address %d)\n",pt,pt*PAGESIZE);
    printf("  Entries: "); for(int i=0;i<NUM_LOGICAL_PAGES;i++) printf("P%d->F%u%s",i,m[pt*PAGESIZE+i],i==NUM_LOGICAL_PAGES-1?"":"  "); printf("\n");
}

void os_run(void) {
    while(active_count()>0){
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id>=0){
                process_instructions(tasks[i].proc_id,10);
            }
        }
        release_finished();
    }
}

static void submit_shell_line(const char *line, int *serial) {
    if (strcmp(line, "exit") == 0) return;
    char program[256], data[256];
    if (sscanf(line, "%255s %255s", program, data) == 2) {
        char pbyte[256], dbyte[256];
        snprintf(pbyte, sizeof(pbyte), "shell_%d.program.byte", *serial);
        snprintf(dbyte, sizeof(dbyte), "shell_%d.data.byte", (*serial)++);
        if (compile_program(program, pbyte) == 0 && copy_data_file(data, dbyte) == 0)
            os_add_task(pbyte, dbyte);
    } else if (line[0] != '\0') {
        printf("\nUsage: <program.txt|program.byte> <data.byte>\n");
    }
}

void os_shell(void) {
    char line[512];
    int len = 0, serial = 0, exit_requested = 0;

#ifndef _WIN32
    struct termios oldt, raw;
    int have_tty = isatty(STDIN_FILENO);
    if (have_tty && tcgetattr(STDIN_FILENO, &oldt) == 0) {
        raw = oldt;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    }
#else
    int have_tty = 1;
#endif

    printf("$ "); fflush(stdout);
    while (!exit_requested) {
        /* One scheduler time slice, then poll the shell. */
        int any = active_count();
        if (any > 0) {
            for (int i = 0; i < MAX_TASKS; ++i)
                if (tasks[i].active && tasks[i].proc_id >= 0)
                    process_instructions(tasks[i].proc_id, 10);
            release_finished();
        }

#ifndef _WIN32
        fd_set set;
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        struct timeval tv = {0, 0};
        int ready = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
        if (ready > 0 && FD_ISSET(STDIN_FILENO, &set)) {
            char ch;
            while (read(STDIN_FILENO, &ch, 1) == 1) {
                if (ch == '\r' || ch == '\n') {
                    line[len] = '\0';
                    if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                    submit_shell_line(line, &serial);
                    len = 0;
                    printf("\n$ "); fflush(stdout);
                } else if (ch == 127 || ch == '\b') {
                    if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
                } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                    line[len++] = ch;
                    putchar(ch); fflush(stdout);
                }
            }
        }
#else
        while (_kbhit()) {
            int ch = _getch();
            if (ch == '\r' || ch == '\n') {
                line[len] = '\0';
                if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                submit_shell_line(line, &serial);
                len = 0;
                printf("\n$ "); fflush(stdout);
            } else if (ch == 8) {
                if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
            } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                line[len++] = (char)ch;
                putchar(ch); fflush(stdout);
            }
        }
#endif

        if (!have_tty && active_count() == 0) {
            /* For redirected stdin, fall back to blocking line input. */
            if (fgets(line, sizeof(line), stdin) == NULL) break;
            line[strcspn(line, "\r\n")] = '\0';
            if (strcmp(line, "exit") == 0) break;
            submit_shell_line(line, &serial);
            printf("$ "); fflush(stdout);
        }

        if (active_count() == 0 && !have_tty) break;
    }

#ifndef _WIN32
    if (have_tty) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
    /* After 'exit', the shell stops accepting new tasks; existing tasks continue. */
    os_run();
    putchar('\n');
}


void os_print_memory_map(void) {
    unsigned char *m = physical_memory();
    printf("\n========== PHYSICAL MEMORY MAP ==========""\n");
    printf("Frame size: %d bytes | Physical memory: %d bytes | Frames: %d\n", PAGESIZE, MEMSIZE, NUM_PHYSICAL_PAGES);
    for (int p = 0; p < NP; ++p) {
        if (!processors[p].used && processors[p].page_table_frame < 0) continue;
        int pt = processors[p].page_table_frame;
        printf("Processor %d: PID-context, page-table frame=%d\n", p, pt);
        if (pt >= 0) {
            int base = pt * PAGESIZE;
            printf("  PT physical range: 0x%04X-0x%04X\n", base, base + PAGESIZE - 1);
            printf("  Instruction: ");
            int found = 0;
            for (int i=0;i<INST_LOGICAL_SIZE/PAGESIZE;i++) if (m[base+i]) { printf("F%d ",m[base+i]); found=1; }
            if (!found) printf("none");
            printf("\n  Data: "); found=0;
            int db=INST_LOGICAL_SIZE/PAGESIZE;
            for (int i=0;i<DATA_LOGICAL_SIZE/PAGESIZE;i++) if (m[base+db+i]) { printf("F%d ",m[base+db+i]); found=1; }
            if (!found) printf("none");
            printf("\n");
        }
    }
    printf("Free frames: ");
    int n=0; for(int f=1;f<NUM_PHYSICAL_PAGES;f++) if(!free_pages[f]) { printf("F%d ",f); n++; }
    printf("(%d free)\n",n);
    printf("=========================================\n");
}

void os_print_performance(void) {
    printf("\n========== PROCESS PERFORMANCE ==========""\n");
    printf("%-6s %-6s %-12s %-10s %-10s %-8s %-10s %-10s %-10s\n", "PID", "CPU", "Cycles", "TLBHit", "TLBMiss", "CacheHit", "CacheMiss", "MemRead", "MemWrite");
    for (int i=0;i<MAX_TASKS;i++) {
        if (tasks[i].pid <= 0) continue;
        int cpu=tasks[i].proc_id;
        printf("%-6d %-6d %-12llu %-10lu %-10lu %-8lu %-10lu %-10lu %-10lu\n", tasks[i].pid,cpu,tasks[i].cycles,tasks[i].tlb_hits,tasks[i].tlb_misses,tasks[i].cache_hits,tasks[i].cache_misses,tasks[i].memory_reads,tasks[i].memory_writes);
    }
    printf("==========================================\n");
}

void os_print_utilities(void) {
    printf("\nCS527 Utilities:\n");
    printf("  memory-map   : physical frames/page-table mappings\n");
    printf("  performance  : instructions, memory operations and time slices\n");
}

void os_shutdown(void) {
    for(int i=0;i<NP;i++){
        if(processors[i].used) free_task_memory(i, processors[i].page_table_frame);
        processors[i].used=0;
    }
}

/* ---------------- Task 7: five-stage processor pipeline ---------------- */

static int pipe_fetch(int pid, int pc, PipeInst *out) {
    int ph = getPhysicalAddress(pid, 1, pc);
    if (ph < 0 || ph + 3 >= MEMSIZE) return -1;
    unsigned char *m = physical_memory();
    out->valid = 1; out->pc = pc;
    out->op=m[ph]; out->d=m[ph+1]; out->s1=m[ph+2]; out->s2=m[ph+3];
    return 0;
}

static int pipe_dest(PipeInst x) {
    if (!x.valid) return -1;
    switch (x.op) {
        case 1: case 2: case 3: case 4:
        case 5: case 9: case 10: case 11: case 12:
        case 13: case 15:
        case 0x21: case 0x22: case 0x23: case 0x25: case 0x29: case 0x2A: case 0x2B: case 0x2C:
            return x.d;
        default: return -1;
    }
}

static int pipe_is_branch(PipeInst x) { return x.valid && x.op >= 0x10 && x.op <= 0x1E; }
static int pipe_uses_reg(PipeInst x, int r) {
    if (!x.valid || r < 0) return 0;
    switch (x.op) {
        case 1: case 2: case 3: case 4: return x.s1==r || x.s2==r;
        case 5: return x.s2==r;
        case 6: return x.s1==r || x.s2==r;
        case 9: case 10: case 11: case 12: return x.s1==r;
        case 13: return 0;
        case 14: return x.s2==r;
        case 8: return x.s2==r;
        case 0x21: case 0x22: case 0x23: return 0; /* vector source registers */
        case 0x25: return x.s2==r;
        case 0x26: return 0;
        default: return 0;
    }
}

static int pipe_uses_flags(PipeInst x) { return pipe_is_branch(x); }
static int pipe_writes_flags(PipeInst x) {
    return x.valid && (x.op==1 || x.op==2 || x.op==9 || x.op==10);
}

static int pipe_has_hazard(PipeState *q, PipeInst in) {
    int d1=pipe_dest(q->id), d2=pipe_dest(q->ex), d3=pipe_dest(q->mem);
    if (d1>=0 && pipe_uses_reg(in,d1)) return 1;
    if (d2>=0 && pipe_uses_reg(in,d2)) return 1;
    if (d3>=0 && pipe_uses_reg(in,d3)) return 1;
    if (pipe_uses_flags(in) && (pipe_writes_flags(q->id)||pipe_writes_flags(q->ex)||pipe_writes_flags(q->mem))) return 1;
    return 0;
}


static void pipe_init_task(int pid) {
    memset(&pipe_state[pid],0,sizeof(pipe_state[pid]));
    pipe_state[pid].fetch_pc=processors[pid].pc;
}

static void pipe_cycle(int pid) {
    Processor *p=&processors[pid];
    PipeState *q=&pipe_state[pid];
    q->pipe_cycles++;

    int taken_branch=0;
    if (q->wb.valid) {
        p->pc=q->wb.pc;
        int oldpc=p->pc;
        processor_step(pid);
        q->retired++;
        if (pipe_is_branch(q->wb) && p->pc != oldpc+4) {
            taken_branch=1;
            q->flushes++;
            q->ifs.valid=q->id.valid=q->ex.valid=q->mem.valid=0;
            q->fetch_pc=p->pc;
        }
        if (q->wb.op==0) {
            q->ifs.valid=q->id.valid=q->ex.valid=q->mem.valid=0;
            p->finished=1;
            return;
        }
    }

    if (taken_branch) {
        q->wb.valid=0;
        return; /* four younger instructions are flushed */
    }

    int stall = q->id.valid && pipe_has_hazard(q, q->id);
    if (stall) {
        /* WB and MEM continue to retire/drain; ID/IF are held and EX gets a bubble. */
        q->wb=q->mem;
        q->mem=q->ex;
        q->ex.valid=0;
        q->stalls++;
        return;
    }

    q->wb=q->mem;
    q->mem=q->ex;
    q->ex=q->id;
    q->id=q->ifs;

    PipeInst next_if={0};
    if (pipe_fetch(pid,q->fetch_pc,&next_if)==0) {
        q->ifs=next_if;
        q->fetch_pc+=4;
    } else {
        q->ifs.valid=0;
    }
}

void os_run_pipeline(void) {
    for (int p=0;p<NP;p++) if (processors[p].used && !processors[p].finished) pipe_init_task(p);

    unsigned long long guard=0;
    while (active_count()>0 && guard++ < 1000000ULL) {
        for (int i=0;i<MAX_TASKS;i++) {
            if (tasks[i].active && tasks[i].proc_id>=0 && !processors[tasks[i].proc_id].finished)
                pipe_cycle(tasks[i].proc_id);
        }
        release_finished();
    }

    printf("\n========== PIPELINE STATISTICS ==========\n");
    printf("5 stages: IF | ID | EX | MEM | WB\n");
    printf("PID    PipelineCycles   Retired   Stalls   Flushes   CPI\n");
    /* Finished tasks have already been released, so use the retained task
       statistics for a compact report and explain timing in README. */
    for (int i=0;i<MAX_TASKS;i++) {
        if (tasks[i].pid>0 && !tasks[i].active) {
            double cpi = tasks[i].pipeline_retired ? (double)tasks[i].pipeline_cycles/(double)tasks[i].pipeline_retired : 0.0;
            printf("%3d    %14llu   %7lu   %6lu   %7lu   %.2f\n",
                   tasks[i].pid, tasks[i].pipeline_cycles, tasks[i].pipeline_retired,
                   tasks[i].pipeline_stalls, tasks[i].pipeline_flushes, cpi);
        }
    }
    printf("==========================================\n");
}
