#include "memory.h"
#include <string.h>

static unsigned char memory_array[MEMSIZE];

void memory_reset(void) {
    memset(memory_array, 0, sizeof(memory_array));
}

unsigned char *physical_memory(void) {
    return memory_array;
}
