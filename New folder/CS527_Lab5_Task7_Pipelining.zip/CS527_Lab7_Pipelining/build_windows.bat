@echo off
where gcc >nul 2>&1
if errorlevel 1 (
  echo GCC not found in PATH.
  exit /b 1
)
gcc -Wall -Wextra -std=c11 -O2 -o cs527_lab.exe main.c compiler.c processor.c memory.c os.c pipeline.c
if errorlevel 1 exit /b 1
echo Build successful: cs527_lab.exe
