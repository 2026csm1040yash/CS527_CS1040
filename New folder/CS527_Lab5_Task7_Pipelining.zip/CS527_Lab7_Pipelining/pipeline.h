#ifndef PIPELINE_H
#define PIPELINE_H

/* Five-stage in-order pipeline: IF, ID, EX, MEM, WB.
 * The simulator executes an instruction when it reaches WB.  RAW and flag
 * hazards are detected conservatively, and taken branches flush younger work.
 */
void pipeline_enable(int enabled);
int pipeline_is_enabled(void);

#endif
