#ifndef PROCESSOR_H
#define PROCESSOR_H
#include "memory.h"
#define NP 4
#define INT_REGS 256
#define VEC_REGS 32
#define VEC_LANES 8
#define PAGE_TABLE_ENTRIES NUM_LOGICAL_PAGES
typedef struct {
    int used, finished, proc_id, pc;
    unsigned int regs[INT_REGS];
    unsigned int vregs[VEC_REGS][VEC_LANES];
    int page_table_frame;
    int z,n,c,v;
    char log_file[128];
    unsigned long instructions_executed;
    unsigned long memory_reads;
    unsigned long memory_writes;
    unsigned long context_switches;
    unsigned long time_slices;
    /* Task 6: cache/TLB and timing statistics */
    unsigned long long cycles;
    unsigned long tlb_hits, tlb_misses;
    unsigned long cache_hits, cache_misses;
    unsigned long instruction_cache_hits, instruction_cache_misses;
    unsigned long data_cache_hits, data_cache_misses;
} Processor;
extern Processor processors[NP];
void processor_reset(int pid);
int getPhysicalAddress(int proc_id,int isFetch,int logical_address);
int processor_step(int pid);
void process_instructions(int pid,int instruction_count);
void processor_set_cache_tlb_enabled(int enabled);
int processor_cache_tlb_enabled(void);
#endif
