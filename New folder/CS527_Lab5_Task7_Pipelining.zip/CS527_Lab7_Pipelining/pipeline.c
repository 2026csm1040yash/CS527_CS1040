#include "pipeline.h"
static int enabled = 0;
void pipeline_enable(int e) { enabled = e ? 1 : 0; }
int pipeline_is_enabled(void) { return enabled; }
