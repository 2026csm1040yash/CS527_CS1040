#ifndef MEMORY_H
#define MEMORY_H

#include <stddef.h>

#define MEMSIZE 8192
#define PAGESIZE 512
#define INST_LOGICAL_SIZE 1024
#define DATA_LOGICAL_SIZE 4096
#define NUM_LOGICAL_PAGES ((INST_LOGICAL_SIZE + DATA_LOGICAL_SIZE) / PAGESIZE)
#define NUM_PHYSICAL_PAGES (MEMSIZE / PAGESIZE)

void memory_reset(void);
unsigned char *physical_memory(void);

#endif
