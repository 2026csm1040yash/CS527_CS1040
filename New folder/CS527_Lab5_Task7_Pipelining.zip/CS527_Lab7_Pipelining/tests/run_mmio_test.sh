#!/bin/sh
set -e
./cs527_lab tests/mmio_console.txt tests/mmio_console.data
printf '\n--- STATUS REGISTER ---\n'
./cs527_lab tests/mmio_status.txt tests/mmio_status.data
