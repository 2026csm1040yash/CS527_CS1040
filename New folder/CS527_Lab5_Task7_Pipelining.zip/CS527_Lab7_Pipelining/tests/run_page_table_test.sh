#!/bin/sh
set -e
./cs527_lab tests/task1.txt tests/task1.data tests/task2.txt tests/task2.data tests/task3.txt tests/task3.data tests/task4.txt tests/task4.data tests/task5.txt tests/task5.data
