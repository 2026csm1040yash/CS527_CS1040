@echo off
setlocal
call ..\build_windows.bat
if errorlevel 1 exit /b 1
echo.
echo === WITH CACHE + TLB ===
cs527_lab.exe --timing tests\cache_tlb_test.txt tests\cache_tlb_test.data
echo.
echo === BASELINE WITHOUT CACHE + TLB ===
cs527_lab.exe --no-cache-tlb --timing tests\cache_tlb_test.txt tests\cache_tlb_test.data
endlocal
