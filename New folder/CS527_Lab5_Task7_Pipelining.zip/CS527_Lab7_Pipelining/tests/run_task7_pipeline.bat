@echo off
call build_windows.bat
if errorlevel 1 exit /b 1
echo.
echo --- RAW dependency pipeline test ---
cs527_lab.exe --pipeline tests\pipeline_test.txt tests\pipeline_test.data
echo.
echo --- Branch flush pipeline test ---
cs527_lab.exe --pipeline tests\pipeline_branch_test.txt tests\pipeline_test.data
