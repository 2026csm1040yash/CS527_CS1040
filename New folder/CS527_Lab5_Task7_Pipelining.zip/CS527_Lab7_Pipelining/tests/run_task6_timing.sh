#!/bin/sh
set -e
make
printf '\n=== WITH CACHE + TLB ===\n'
./cs527_lab --timing tests/cache_tlb_test.txt tests/cache_tlb_test.data
printf '\n=== BASELINE WITHOUT CACHE + TLB ===\n'
./cs527_lab --no-cache-tlb --timing tests/cache_tlb_test.txt tests/cache_tlb_test.data
