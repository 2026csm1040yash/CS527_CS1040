#!/bin/sh
set -e
./cs527_lab --utils
./cs527_lab --memory-map tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
./cs527_lab --performance tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
./cs527_lab --all-utils tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
