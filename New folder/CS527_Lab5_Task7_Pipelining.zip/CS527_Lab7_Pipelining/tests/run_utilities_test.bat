@echo off
cs527_lab.exe --utils
cs527_lab.exe --memory-map tests\util_test.txt tests\util_test.data tests\util_test2.txt tests\util_test2.data
cs527_lab.exe --performance tests\util_test.txt tests\util_test.data tests\util_test2.txt tests\util_test2.data
cs527_lab.exe --all-utils tests\util_test.txt tests\util_test.data tests\util_test2.txt tests\util_test2.data
