#!/bin/sh
set -e
make
printf '\n--- RAW dependency pipeline test ---\n'
./cs527_lab --pipeline tests/pipeline_test.txt tests/pipeline_test.data
printf '\n--- Branch flush pipeline test ---\n'
./cs527_lab --pipeline tests/pipeline_branch_test.txt tests/pipeline_test.data
