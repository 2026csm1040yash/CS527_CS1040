@echo off
cs527_lab.exe tests\mmio_console.txt tests\mmio_console.data
echo.
echo --- STATUS REGISTER ---
cs527_lab.exe tests\mmio_status.txt tests\mmio_status.data
