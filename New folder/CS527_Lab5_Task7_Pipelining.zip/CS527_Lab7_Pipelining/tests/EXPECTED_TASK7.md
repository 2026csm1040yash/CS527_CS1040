# Expected Task 7 behavior

`pipeline_test.txt` is a dependency-heavy sequence and should report a non-zero `Stalls` value.

`pipeline_branch_test.txt` contains a taken `BEQ` and should report a non-zero `Flushes` value.

The output columns are:

- PipelineCycles: total simulated five-stage pipeline cycles
- Retired: instructions that reached WB
- Stalls: cycles inserted for detected hazards
- Flushes: taken-branch flush events
- CPI: PipelineCycles / Retired
