#ifndef COMPILER_H
#define COMPILER_H

int compile_program(const char *source_file, const char *program_byte_file);
int copy_data_file(const char *source_data_file, const char *data_byte_file);

#endif
