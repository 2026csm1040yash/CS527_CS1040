# CS527 Lab 5 - Task 7: Implement Pipelining in Processor

## What this task adds

A five-stage in-order pipeline is added around the existing processor:

```text
IF -> ID -> EX -> MEM -> WB
```

The simulator keeps the existing Lab 5 architectural state, paging, physical-memory page tables, MMIO, cache/TLB and OS. An instruction is architecturally executed when it reaches **WB**.

### Pipeline features

- Five pipeline stages: IF, ID, EX, MEM, WB
- One instruction can be fetched each cycle when there is no hazard
- RAW (read-after-write) hazard detection for integer-register dependencies
- Conservative flag hazard detection for conditional branches
- Taken-branch flushing of younger pipeline entries
- Pipeline cycle counter
- Retired instruction counter
- Stall counter
- Branch-flush counter
- CPI calculation

The implementation is intentionally **in-order**. It does not change the instruction semantics of the existing processor; it adds pipeline timing/control around the existing `processor_step()` architectural execution.

## Build

### Linux

```bash
make
```

### Windows / MinGW

```powershell
.\build_windows.bat
```

The Windows batch file invokes GCC directly, so GNU Make is not required.

## Run

Normal processor execution:

```bash
./cs527_lab tests/pipeline_test.txt tests/pipeline_test.data
```

Five-stage pipeline:

```bash
./cs527_lab --pipeline tests/pipeline_test.txt tests/pipeline_test.data
```

Windows:

```powershell
.\cs527_lab.exe --pipeline tests\pipeline_test.txt tests\pipeline_test.data
```

Options may be combined in any order before the program/data pairs:

```powershell
.\cs527_lab.exe --pipeline --timing tests\pipeline_test.txt tests\pipeline_test.data
```

## Tests

### 1. RAW dependency test

`tests/pipeline_test.txt` contains a dependency chain:

```text
x1 = 10
x2 = x1 + 5
x3 = x2 + 7
x4 = x3 + 2
x5 = x4 + 1
print x5
```

This should produce **non-zero pipeline stalls**.

### 2. Branch flush test

`tests/pipeline_branch_test.txt` contains a taken `BEQ`. It should produce a **non-zero flush count**.

Run:

```bash
./cs527_lab --pipeline tests/pipeline_branch_test.txt tests/pipeline_test.data
```

## Expected form of output

```text
========== PIPELINE STATISTICS ==========
5 stages: IF | ID | EX | MEM | WB
PID    PipelineCycles   Retired   Stalls   Flushes   CPI
  1                ...       ...      ...       ...   ...
==========================================
```

On the supplied tests, the exact numbers depend on the instruction stream and the existing memory/cache/TLB timing implementation, but the dependency test must report stalls and the taken-branch test must report a flush.

## Relationship to the CS527 specification

The Lab 5 document specifies the processor functions `reset()`, `fetch()`, `decode()`, `execute()` and the sliced `process_instructions()` execution interface. This task extends that processor model with a five-stage pipeline rather than replacing the architectural instruction set. The Lab 5 specification also keeps the processor's 256 integer registers and 32 vector registers.
