#ifndef OS_H
#define OS_H

#define NP 4

void os_init(void);
int os_add_task(const char *program_file, const char *data_file);
void os_run(void);
void os_run_pipeline(void);
void os_shell(void);
void os_shutdown(void);
void os_print_memory_map(void);
void os_print_performance(void);
void os_print_utilities(void);

#endif
