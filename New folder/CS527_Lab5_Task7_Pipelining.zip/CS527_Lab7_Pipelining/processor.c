#define _POSIX_C_SOURCE 200809L
#include "processor.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#ifdef _WIN32
#include <windows.h>
#endif
Processor processors[NP];

/* Task 6: small direct-mapped TLB and cache in the processor.
 * TLB: 4 entries, maps logical page -> physical frame per process.
 * Cache: 8 lines, 16 bytes/line, write-through.  Instruction and data
 * accesses use separate logical caches but share the same physical cache
 * array here for simplicity of the simulator.
 */
#define TLB_ENTRIES 4
#define CACHE_LINES 8
#define CACHE_LINE_SIZE 16
#define TLB_HIT_CYCLES 1
#define TLB_MISS_CYCLES 10
#define CACHE_HIT_CYCLES 1
#define CACHE_MISS_CYCLES 20
#define BASE_INSTRUCTION_CYCLES 1

typedef struct { int valid, pid, logical_page, frame; unsigned long age; } TLBEntry;
typedef struct { int valid, tag; unsigned char data[CACHE_LINE_SIZE]; } CacheLine;
static TLBEntry tlb[TLB_ENTRIES];
static CacheLine cache_lines[CACHE_LINES];
static unsigned long tlb_age;
static int cache_tlb_enabled=1;

void processor_set_cache_tlb_enabled(int enabled){ cache_tlb_enabled=enabled?1:0; }
int processor_cache_tlb_enabled(void){ return cache_tlb_enabled; }
static void cache_tlb_reset(void) {
    memset(tlb,0,sizeof(tlb)); memset(cache_lines,0,sizeof(cache_lines)); tlb_age=0;
}
static int tlb_lookup(int pid,int lp,int *frame) {
    int best=-1;
    for(int i=0;i<TLB_ENTRIES;i++) if(tlb[i].valid && tlb[i].pid==pid && tlb[i].logical_page==lp){*frame=tlb[i].frame; tlb[i].age=++tlb_age; return 1;}
    return 0;
}
static void tlb_insert(int pid,int lp,int frame) {
    int slot=-1; unsigned long min=~0UL;
    for(int i=0;i<TLB_ENTRIES;i++){ if(!tlb[i].valid){slot=i;break;} if(tlb[i].age<min){min=tlb[i].age;slot=i;} }
    tlb[slot]=(TLBEntry){1,pid,lp,frame,++tlb_age};
}
static int cache_access(int pid,int phys,unsigned char *out,int is_write,unsigned char value) {
    if(!cache_tlb_enabled){ if(is_write) physical_memory()[phys]=value; else *out=physical_memory()[phys]; return 0; }
    (void)pid;
    int line=(phys/CACHE_LINE_SIZE)%CACHE_LINES, tag=phys/CACHE_LINE_SIZE/CACHE_LINES, off=phys%CACHE_LINE_SIZE;
    CacheLine *c=&cache_lines[line];
    int hit=c->valid && c->tag==tag;
    Processor *p=&processors[pid];
    if(hit){ p->cache_hits++; if(is_write){c->data[off]=value; physical_memory()[phys]=value;} else *out=c->data[off]; p->cycles+=CACHE_HIT_CYCLES; return 1; }
    p->cache_misses++;
    int base=phys-off;
    c->valid=1; c->tag=tag;
    memcpy(c->data,physical_memory()+base,CACHE_LINE_SIZE);
    if(is_write){c->data[off]=value; physical_memory()[phys]=value;} else *out=c->data[off];
    p->cycles+=CACHE_MISS_CYCLES; return 0;
}
static void cache_writeback_all(void) { /* write-through cache: nothing pending */ }
static void addf(Processor*p,uint32_t a,uint32_t b,uint32_t r){uint64_t u=(uint64_t)a+b;int32_t x=a,y=b,z=r;p->z=!r;p->n=(r>>31)&1;p->c=u>0xffffffffULL;p->v=((x>=0&&y>=0&&z<0)||(x<0&&y<0&&z>=0));}
static void subf(Processor*p,uint32_t a,uint32_t b,uint32_t r){int32_t x=a,y=b,z=r;p->z=!r;p->n=(r>>31)&1;p->c=a>b;p->v=((x<0&&y>=0&&z>=0)||(x>=0&&y<0&&z<0));}
/* Task 3: the page table contents are stored in a physical-memory frame. */
int getPhysicalAddress(int pid,int fetch,int la){
    if(pid<0||pid>=NP||la<0) return -1;
    Processor*p=&processors[pid];
    if(p->page_table_frame<=0||p->page_table_frame>=NUM_PHYSICAL_PAGES)return -1;
    int idx=fetch?la/PAGESIZE:la/PAGESIZE+INST_LOGICAL_SIZE/PAGESIZE;
    if(idx<0||idx>=PAGE_TABLE_ENTRIES)return -1;
    int lp=idx, frame;
    if(!cache_tlb_enabled){ unsigned char*m=physical_memory(); int pt=p->page_table_frame*PAGESIZE; frame=m[pt+idx]; if(frame<=0||frame>=NUM_PHYSICAL_PAGES)return -1; return frame*PAGESIZE+la%PAGESIZE; }
    if(tlb_lookup(pid,lp,&frame)) { p->tlb_hits++; p->cycles+=TLB_HIT_CYCLES; return frame*PAGESIZE+la%PAGESIZE; }
    p->tlb_misses++; p->cycles+=TLB_MISS_CYCLES;
    unsigned char*m=physical_memory(); int pt=p->page_table_frame*PAGESIZE; frame=m[pt+idx];
    if(frame<=0||frame>=NUM_PHYSICAL_PAGES)return -1;
    tlb_insert(pid,lp,frame);
    return frame*PAGESIZE+la%PAGESIZE;
}

void processor_reset(int pid){Processor*p=&processors[pid];memset(p->regs,0,sizeof p->regs);memset(p->vregs,0,sizeof p->vregs);p->pc=0;p->z=p->n=p->c=p->v=0;p->finished=0; p->cycles=0; p->tlb_hits=p->tlb_misses=p->cache_hits=p->cache_misses=0; p->instruction_cache_hits=p->instruction_cache_misses=p->data_cache_hits=p->data_cache_misses=0; for(int ti=0;ti<TLB_ENTRIES;ti++) if(tlb[ti].valid && tlb[ti].pid==pid) tlb[ti].valid=0; FILE*f=fopen(p->log_file,"a");if(f){fprintf(f,"Process %d started; page_table_frame=%d\n",pid,p->page_table_frame);fclose(f);}}
static uint32_t l32(int x){unsigned char*m=physical_memory();return m[x]|m[x+1]<<8|((uint32_t)m[x+2]<<16)|((uint32_t)m[x+3]<<24);}
static void s32(int x,uint32_t v){unsigned char*m=physical_memory();m[x]=v;m[x+1]=v>>8;m[x+2]=v>>16;m[x+3]=v>>24;}
/* Task 4: Memory-mapped I/O. These logical data addresses are reserved as device registers.
 * 0xF00 = console DATA (write low byte to stdout)
 * 0xF04 = console STATUS (read returns 1 = ready)
 * 0xF08 = console HEX (write prints a 32-bit value in hexadecimal)
 */
#define MMIO_CONSOLE_DATA 0xF0
#define MMIO_CONSOLE_STATUS 0xF4
#define MMIO_CONSOLE_HEX 0xF8
static int mmio_read(int a,uint32_t*o){if(a==MMIO_CONSOLE_STATUS){*o=1;return 1;}return 0;}
static int mmio_write(int a,uint32_t v){if(a==MMIO_CONSOLE_DATA){putchar((unsigned char)(v&0xFF));fflush(stdout);return 1;}if(a==MMIO_CONSOLE_HEX){printf("%08X",v);fflush(stdout);return 1;}return 0;}
static int rd(int pid,int a,uint32_t*o){
    if(mmio_read(a,o)){processors[pid].cycles+=5;return 0;}
    int p=getPhysicalAddress(pid,0,a);if(p<0||p+3>=MEMSIZE)return -1;
    processors[pid].memory_reads++;
    unsigned char b0,b1,b2,b3; cache_access(pid,p,&b0,0,0); cache_access(pid,p+1,&b1,0,0); cache_access(pid,p+2,&b2,0,0); cache_access(pid,p+3,&b3,0,0);
    *o=(uint32_t)b0|((uint32_t)b1<<8)|((uint32_t)b2<<16)|((uint32_t)b3<<24); processors[pid].data_cache_hits=processors[pid].cache_hits; processors[pid].data_cache_misses=processors[pid].cache_misses; return 0;
}
static int wr(int pid,int a,uint32_t v){
    if(mmio_write(a,v)){processors[pid].cycles+=5;return 0;}
    int p=getPhysicalAddress(pid,0,a);if(p<0||p+3>=MEMSIZE)return -1;
    processors[pid].memory_writes++;
    cache_access(pid,p,NULL,1,(unsigned char)v); cache_access(pid,p+1,NULL,1,(unsigned char)(v>>8)); cache_access(pid,p+2,NULL,1,(unsigned char)(v>>16)); cache_access(pid,p+3,NULL,1,(unsigned char)(v>>24)); processors[pid].data_cache_hits=processors[pid].cache_hits; processors[pid].data_cache_misses=processors[pid].cache_misses; return 0;
}
int processor_step(int pid){Processor*p=&processors[pid];
    p->instructions_executed++;if(!p->used||p->finished)return 0;int ph=getPhysicalAddress(pid,1,p->pc);if(ph<0||ph+3>=MEMSIZE){p->finished=1;fprintf(stderr,"PID %d invalid PC\n",pid);return -1;}unsigned char*m=physical_memory();unsigned op=m[ph],d=m[ph+1],s1=m[ph+2],s2=m[ph+3];int old=p->pc;p->pc+=4;
    /* Instruction fetch goes through the TLB and instruction cache. */
    unsigned char ib[4];
    int ih=1;
    for(int k=0;k<4;k++){ int cp=getPhysicalAddress(pid,1,p->pc-4+k); if(cp<0||cp>=MEMSIZE){p->finished=1;return -1;} unsigned long before=p->cache_hits; cache_access(pid,cp,&ib[k],0,0); if(cache_tlb_enabled && p->cache_hits==before) ih=0; }
    op=ib[0];d=ib[1];s1=ib[2];s2=ib[3];
    if(cache_tlb_enabled){ if(ih)p->instruction_cache_hits++; else p->instruction_cache_misses++; }
    p->cycles+=BASE_INSTRUCTION_CYCLES;
    if(!op){p->finished=1;return 0;}uint32_t a,b,r;int addr;
switch(op){
case 1:a=p->regs[s1];b=p->regs[s2];r=a+b;p->regs[d]=r;addf(p,a,b,r);break;
case 2:a=p->regs[s1];b=p->regs[s2];r=a-b;p->regs[d]=r;subf(p,a,b,r);break;
case 3:p->regs[d]=p->regs[s1]*p->regs[s2];break;
case 4:if(!p->regs[s2]){p->finished=1;break;}p->regs[d]=p->regs[s1]/p->regs[s2];break;
case 9:a=p->regs[s1];b=s2;r=a+b;p->regs[d]=r;addf(p,a,b,r);break;
case 10:a=p->regs[s1];b=s2;r=a-b;p->regs[d]=r;subf(p,a,b,r);break;
case 11:p->regs[d]=p->regs[s1]*s2;break;
case 12:if(!s2){p->finished=1;break;}p->regs[d]=p->regs[s1]/s2;break;
case 5:addr=p->regs[s2];if(rd(pid,addr,&r))p->finished=1;else p->regs[d]=r;break;
case 13:addr=s2;if(rd(pid,addr,&r))p->finished=1;else p->regs[d]=r;break;
case 6:addr=p->regs[s1];if(wr(pid,addr,p->regs[s2]))p->finished=1;break;
case 14:addr=s1;if(wr(pid,addr,p->regs[s2]))p->finished=1;break;
case 15:p->regs[d]=s2;break;
case 8:{FILE*f=fopen(p->log_file,"a");if(f){fprintf(f,"Process id: x%u : %08X\n",s2,p->regs[s2]);fclose(f);}break;}
case 0x21:case 0x22:case 0x23:for(int i=0;i<8;i++)p->vregs[d][i]=(op==0x21)?p->vregs[s1][i]+p->vregs[s2][i]:(op==0x22)?p->vregs[s1][i]-p->vregs[s2][i]:p->vregs[s1][i]*p->vregs[s2][i];break;
case 0x29:case 0x2A:case 0x2B:for(int i=0;i<8;i++)p->vregs[d][i]=(op==0x29)?p->vregs[s1][i]+s2:(op==0x2A)?p->vregs[s1][i]-s2:p->vregs[s1][i]*s2;break;
case 0x25:case 0x2C:addr=(op==0x25)?p->regs[s2]:s2;for(int i=0;i<8;i++,addr+=4){if(rd(pid,addr,&r)){p->finished=1;break;}p->vregs[d][i]=r;}break;
case 0x26:case 0x2E:addr=(op==0x26)?p->regs[s1]:s1;for(int i=0;i<8;i++,addr+=4){if(wr(pid,addr,p->vregs[s2][i])){p->finished=1;break;}}break;
default:if(op>=0x10&&op<=0x1E){int t=0;switch(op-0x10){case 0:t=p->z;break;case 1:t=!p->z;break;case 2:t=p->c;break;case 3:t=!p->c;break;case 4:t=p->n;break;case 5:t=!p->n;break;case 6:t=p->v;break;case 7:t=!p->v;break;case 8:t=p->c&&!p->z;break;case 9:t=!p->c||p->z;break;case 10:t=p->n==p->v;break;case 11:t=p->n!=p->v;break;case 12:t=!p->z&&p->n==p->v;break;case 13:t=p->z||p->n!=p->v;break;case 14:t=1;break;}if(t)p->pc=old+(int8_t)s2;}else{fprintf(stderr,"PID %d unknown opcode %02X\n",pid,op);p->finished=1;}}
#ifdef _WIN32
Sleep(1);
#else
struct timespec ts={0,10000};nanosleep(&ts,NULL);
#endif
return 1;}
void process_instructions(int pid,int n){
    if(processors[pid].used && !processors[pid].finished) processors[pid].time_slices++;
    for(int i=0;i<n&&!processors[pid].finished;i++) processor_step(pid);
}
