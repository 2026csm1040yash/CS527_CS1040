With 3 physical registers, the report should show liveness information,
interference-based coloring, and one or more spill slots. Exact assignments
may vary because graph-coloring choices are not unique.
