#!/bin/sh
set -e
gcc -Wall -Wextra -std=c11 main.c allocator.c -o cs527_register_alloc
./cs527_register_alloc tests/allocator_test.txt 3 allocated.txt
cat allocated.txt
