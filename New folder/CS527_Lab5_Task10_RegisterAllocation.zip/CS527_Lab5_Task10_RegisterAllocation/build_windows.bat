@echo off
gcc -Wall -Wextra -std=c11 main.c allocator.c -o cs527_register_alloc.exe
if errorlevel 1 exit /b 1
echo Build successful.
