#include <stdio.h>
#include <stdlib.h>
#include "allocator.h"
int main(int argc,char**argv){
 if(argc<3){printf("usage: %s input physical_registers [output]\n",argv[0]);return 1;}
 const char*out=argc>3?argv[3]:"allocated.txt";
 if(allocate_file(argv[1],out,atoi(argv[2]))){printf("allocation failed\n");return 1;}
 printf("Allocation complete: %s\n",out);return 0;
}
