#ifndef ALLOCATOR_H
#define ALLOCATOR_H
int allocate_file(const char *input,const char *output,int physical_regs);
#endif
