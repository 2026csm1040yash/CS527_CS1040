#include "allocator.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define V 64
#define I 256
typedef struct { char op[16]; char a[32],b[32],c[32]; int n; } Ins;
static int use[I][V], def[I][V], in[I][V], out[I][V], adj[V][V];

static int isv(const char*s){return s && s[0]=='v' && atoi(s+1)>=0 && atoi(s+1)<V;}
static int vi(const char*s){return atoi(s+1);}
static void parse(char *line,Ins*x,int i){
 char*t[4]={0}; int n=0; char*p=strtok(line," \t,\n");
 while(p&&n<4){t[n++]=p;p=strtok(NULL," \t,\n");}
 memset(x,0,sizeof(*x)); x->n=n; if(!n)return;
 strncpy(x->op,t[0],15);
 if(n>1)strncpy(x->a,t[1],31); if(n>2)strncpy(x->b,t[2],31); if(n>3)strncpy(x->c,t[3],31);
 if(!strcmp(x->op,"MOV")||!strcmp(x->op,"LOAD")) {if(n>1&&isv(t[1]))def[i][vi(t[1])]=1;}
 else if(!strcmp(x->op,"STORE")||!strcmp(x->op,"PRINT")) {if(n>1&&isv(t[1]))use[i][vi(t[1])]=1;}
 else if(!strcmp(x->op,"ADD")||!strcmp(x->op,"SUB")||!strcmp(x->op,"MUL")){
   if(n>1&&isv(t[1]))def[i][vi(t[1])]=1;
   if(n>2&&isv(t[2]))use[i][vi(t[2])]=1;
   if(n>3&&isv(t[3]))use[i][vi(t[3])]=1;
 }
}
int allocate_file(const char*input,const char*output,int K){
 FILE*f=fopen(input,"r"),*o=fopen(output,"w"); if(!f||!o||K<1||K>32)return -1;
 Ins a[I]; int n=0; char line[256];
 while(fgets(line,sizeof(line),f)&&n<I){parse(line,&a[n],n);n++;}
 fclose(f);
 int changed=1;
 while(changed){changed=0;
  for(int i=n-1;i>=0;i--)for(int v=0;v<V;v++){
   int ni=use[i][v]||(out[i][v]&&!def[i][v]), no=(i+1<n)?in[i+1][v]:0;
   if(in[i][v]!=ni){in[i][v]=ni;changed=1;} if(out[i][v]!=no){out[i][v]=no;changed=1;}
  }
 }
 for(int i=0;i<n;i++)for(int d=0;d<V;d++)if(def[i][d])
  for(int v=0;v<V;v++)if(out[i][v]&&v!=d)adj[d][v]=adj[v][d]=1;
 int degree[V]={0},removed[V]={0},order[V],on=0,color[V];
 for(int v=0;v<V;v++){color[v]=-1;for(int u=0;u<V;u++)degree[v]+=adj[v][u];}
 for(int k=0;k<V;k++){int p=-1;
  for(int v=0;v<V;v++)if(!removed[v]&&degree[v]<K){p=v;break;}
  if(p<0)for(int v=0;v<V;v++)if(!removed[v]){p=v;break;}
  if(p<0)break; order[on++]=p;removed[p]=1;
  for(int u=0;u<V;u++)if(adj[p][u]&&!removed[u])degree[u]--;
 }
 for(int z=on-1;z>=0;z--){int v=order[z],used[32]={0},c=-1;
  for(int u=0;u<V;u++)if(adj[v][u]&&color[u]>=0)used[color[u]]=1;
  for(int k=0;k<K;k++)if(!used[k]){c=k;break;} color[v]=c;
 }
 fprintf(o,"# K=%d\n# virtual -> physical (or SPILL)\n",K);
 for(int v=0;v<V;v++){int active=0;for(int i=0;i<n;i++)if(use[i][v]||def[i][v])active=1;
  if(active)fprintf(o,"# v%d -> %s\n",v,color[v]>=0?"physical register":"SPILL");
 }
 fprintf(o,"# Liveness\n");
 for(int i=0;i<n;i++){fprintf(o,"# I%d IN:",i);for(int v=0;v<V;v++)if(in[i][v])fprintf(o," v%d",v);
  fprintf(o," OUT:");for(int v=0;v<V;v++)if(out[i][v])fprintf(o," v%d",v);fprintf(o,"\n");
  fprintf(o,"%s",a[i].op);if(a[i].n>1)fprintf(o," %s",a[i].a);if(a[i].n>2)fprintf(o," %s",a[i].b);if(a[i].n>3)fprintf(o," %s",a[i].c);fprintf(o,"\n");
 }
 int slot=0;fprintf(o,"# Spill slots\n");
 for(int v=0;v<V;v++){int active=0;for(int i=0;i<n;i++)if(use[i][v]||def[i][v])active=1;
  if(active&&color[v]<0)fprintf(o,"# v%d -> [SP+%d] (insert LOAD before uses / STORE after defs)\n",v,slot++*4);
 }
 fclose(o);return 0;
}
