# CS527 Lab 5 - Task 10
## Virtual registers to physical registers

Implements an educational register allocator demonstrating:
- liveness analysis
- interference graph construction
- graph coloring
- spill selection
- spill-slot reporting

Run on Windows:
    build_windows.bat
    cs527_register_alloc.exe tests\allocator_test.txt 3 allocated.txt

Run on Linux:
    ./run_linux.sh

The test deliberately uses more live virtual registers than the available
physical registers, so spill decisions are visible in allocated.txt.

Liveness uses:
LIVE_IN = USE union (LIVE_OUT - DEF)
and a definition interferes with registers live-out at that instruction.
