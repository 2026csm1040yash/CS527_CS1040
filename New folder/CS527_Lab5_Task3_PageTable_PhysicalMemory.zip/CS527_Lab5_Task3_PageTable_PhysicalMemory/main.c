#include "compiler.h"
#include "os.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void usage(const char *p) {
    printf("Usage:\n");
    printf("  %s program.txt data.byte [program2.txt data2.byte ...]\n", p);
    printf("  %s                 # interactive shell\n", p);
}

int main(int argc, char **argv) {
    os_init();

    if (argc == 1) {
        os_shell();
        os_shutdown();
        return 0;
    }

    if ((argc-1)%2 != 0) {
        usage(argv[0]);
        os_shutdown();
        return 1;
    }

    int task_no=0;
    for(int i=1;i<argc;i+=2){
        char program_byte[256], data_byte[256];
        snprintf(program_byte,sizeof(program_byte),"task%d.program.byte",task_no);
        snprintf(data_byte,sizeof(data_byte),"task%d.data.byte",task_no);
        int p_ok;
        size_t plen = strlen(argv[i]);
        if (plen >= 5 && strcmp(argv[i] + plen - 5, ".byte") == 0) {
            FILE *pin = fopen(argv[i], "rb");
            FILE *pout = fopen(program_byte, "wb");
            p_ok = (pin && pout) ? 0 : -1;
            if (p_ok == 0) {
                int ch; while ((ch = fgetc(pin)) != EOF) fputc(ch, pout);
            }
            if (pin) fclose(pin);
            if (pout) fclose(pout);
        } else {
            p_ok = compile_program(argv[i], program_byte);
        }
        if(p_ok!=0 || copy_data_file(argv[i+1],data_byte)!=0){
            fprintf(stderr,"Failed to prepare task: %s %s\n",argv[i],argv[i+1]);
            os_shutdown();
            return 1;
        }
        if(os_add_task(program_byte,data_byte)<0){
            fprintf(stderr,"Failed to load task %d\n",task_no);
            os_shutdown();
            return 1;
        }
        task_no++;
    }

    os_run();
    os_shutdown();
    return 0;
}
