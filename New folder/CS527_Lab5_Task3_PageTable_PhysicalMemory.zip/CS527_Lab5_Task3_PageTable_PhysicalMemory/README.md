# CS527 Lab 5 - Task 3

## Task
Store each process page table in **physical memory** instead of keeping the page-table entries as an OS/processor array.

## Implementation
- Physical memory: 8192 bytes
- Page/frame size: 512 bytes
- Frame 0 is reserved.
- Each process gets one physical frame for its page table.
- The page table contains 10 one-byte entries (2 instruction pages + 8 data pages in the logical address space).
- `getPhysicalAddress()` reads the page-table entry directly from the physical-memory array.
- When a task finishes, its mapped frames and its page-table frame are freed.
- The page-table frame number is kept only as metadata needed to locate the table; the table entries themselves are in physical memory.

## Verify
Build:

Linux:
```bash
make
```
Windows PowerShell (without `make`):
```powershell
.\build_windows.bat
```

Run:
```powershell
.\cs527_lab.exe tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data tests\task3.txt tests\task3.data tests\task4.txt tests\task4.data tests\task5.txt tests\task5.data
```

The output prints lines such as:
`Page table: physical frame 1 (physical address 512)`
followed by page-to-frame entries. This is the evidence that the page table is stored in physical memory.

The fifth task enters the waiting queue when four processors are occupied and is loaded after a processor is released.
