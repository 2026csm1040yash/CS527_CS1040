#ifndef PROCESSOR_H
#define PROCESSOR_H
#include "memory.h"
#define NP 4
#define INT_REGS 256
#define VEC_REGS 32
#define VEC_LANES 8
#define PAGE_TABLE_ENTRIES NUM_LOGICAL_PAGES
typedef struct {
    int used, finished, proc_id, pc;
    unsigned int regs[INT_REGS];
    unsigned int vregs[VEC_REGS][VEC_LANES];
    int page_table_frame;
    int z,n,c,v;
    char log_file[128];
} Processor;
extern Processor processors[NP];
void processor_reset(int pid);
int getPhysicalAddress(int proc_id,int isFetch,int logical_address);
int processor_step(int pid);
void process_instructions(int pid,int instruction_count);
#endif
