#!/bin/sh
set -e
gcc -Wall -Wextra -std=c11 main.c compiler.c processor.c memory.c os.c -o cs527_lab
./cs527_lab
