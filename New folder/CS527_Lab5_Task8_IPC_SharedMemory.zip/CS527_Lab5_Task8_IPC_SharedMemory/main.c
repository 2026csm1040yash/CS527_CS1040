#include <stdio.h>
#include "memory.h"
#include "os.h"
#include "processor.h"

int main(void){
    memory_init();
    os_init();

    /* Create one 512-byte shared page at logical address 0x200. */
    if(os_create_shared(1,0x200,512)!=0){
        puts("ERROR: cannot create shared region");
        return 1;
    }

    /* Two processes attach the same region. */
    os_attach_shared(0,1);
    os_attach_shared(1,1);

    os_print_shared_map();

    /* PID 0 writes; PID 1 reads the same physical storage. */
    processor_write_shared(0,0x200,12345);
    printf("PID 0 wrote 12345 at shared logical address 0x200\n");
    printf("PID 1 read %u from shared logical address 0x200\n",
           processor_read_shared(1,0x200));

    /* Detach one process; frame remains because PID 1 still references it. */
    os_detach_shared(0,1);
    puts("PID 0 detached shared region.");
    os_print_shared_map();

    /* Last detach releases the physical frame. */
    os_detach_shared(1,1);
    puts("PID 1 detached shared region.");
    os_print_shared_map();

    return 0;
}
