#include "processor.h"
#include "memory.h"
#include <stdio.h>

/*
 * ISA-facing helpers. In a complete simulator these are called by
 * decoded load/store instructions after logical->physical translation.
 * Task 8 keeps the ISA contract explicit while the OS owns sharing.
 */
void processor_write_shared(int pid,unsigned addr,unsigned value){
    (void)pid;
    mem_write32(addr,value);
}
unsigned processor_read_shared(int pid,unsigned addr){
    (void)pid;
    return mem_read32(addr);
}
