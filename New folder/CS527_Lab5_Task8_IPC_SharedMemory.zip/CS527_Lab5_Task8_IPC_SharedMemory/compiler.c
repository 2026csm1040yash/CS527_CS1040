#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "compiler.h"

/*
 * Educational compiler extension for Task 8.
 * It preserves source instructions and emits explicit shared-memory metadata.
 *
 * Syntax:
 *   shared <id> <logical_address> <size>
 *
 * Metadata format:
 *   #SHM id logical_address size
 *
 * The OS/loader consumes these records before loading instructions.
 */
int compile_file(const char *src, const char *out) {
    FILE *in=fopen(src,"r"), *fp=fopen(out,"w");
    char line[256];
    if(!in || !fp) return -1;

    while(fgets(line,sizeof(line),in)) {
        char cmd[32];
        unsigned id, addr, size;
        if(sscanf(line," %31s",cmd)!=1) continue;

        if(strcmp(cmd,"shared")==0 &&
           sscanf(line," %*s %u %x %x",&id,&addr,&size)==3) {
            fprintf(fp,"#SHM %u %u %u\n",id,addr,size);
        } else {
            fputs(line,fp);
        }
    }
    fclose(in); fclose(fp);
    return 0;
}
