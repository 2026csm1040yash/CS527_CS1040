@echo off
gcc -Wall -Wextra -std=c11 main.c compiler.c processor.c memory.c os.c -o cs527_lab.exe
if errorlevel 1 (
  echo Build failed.
  exit /b 1
)
echo Build successful: cs527_lab.exe
