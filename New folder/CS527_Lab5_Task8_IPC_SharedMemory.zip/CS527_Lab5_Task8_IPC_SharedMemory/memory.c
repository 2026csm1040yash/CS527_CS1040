#include "memory.h"
#include <string.h>
unsigned char memory[MEMSIZE];

void memory_init(void){ memset(memory,0,sizeof(memory)); }

uint32_t mem_read32(uint32_t a){
    if(a+3>=MEMSIZE) return 0;
    return (uint32_t)memory[a] |
           ((uint32_t)memory[a+1]<<8) |
           ((uint32_t)memory[a+2]<<16) |
           ((uint32_t)memory[a+3]<<24);
}
void mem_write32(uint32_t a,uint32_t v){
    if(a+3>=MEMSIZE) return;
    memory[a]=v&255; memory[a+1]=(v>>8)&255;
    memory[a+2]=(v>>16)&255; memory[a+3]=(v>>24)&255;
}
