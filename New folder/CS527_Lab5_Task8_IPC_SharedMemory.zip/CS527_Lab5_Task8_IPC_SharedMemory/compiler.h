#ifndef COMPILER_H
#define COMPILER_H
int compile_file(const char *src, const char *out);
#endif
