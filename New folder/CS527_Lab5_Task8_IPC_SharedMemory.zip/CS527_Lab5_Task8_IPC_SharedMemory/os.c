#include "os.h"
#include "memory.h"
#include <stdio.h>
#include <string.h>

static unsigned char page_used[MEMSIZE/PAGESIZE];
static unsigned page_table[MAX_PROC][MEMSIZE/PAGESIZE];
static unsigned attached[MAX_PROC][MAX_SHARED];
static SharedRegion regions[MAX_SHARED];

void os_init(void){
    memset(page_used,0,sizeof(page_used));
    memset(page_table,0xff,sizeof(page_table));
    memset(attached,0,sizeof(attached));
    memset(regions,0,sizeof(regions));
    page_used[0]=1; /* frame 0 reserved */
}

static int free_frame(void){
    for(unsigned f=1; f<MEMSIZE/PAGESIZE; ++f)
        if(!page_used[f]) { page_used[f]=1; return (int)f; }
    return -1;
}

int os_create_shared(unsigned id,unsigned logical_addr,unsigned size){
    if(id>=MAX_SHARED) return -1;
    unsigned pages=(size+PAGESIZE-1)/PAGESIZE;
    if(pages>MAX_SHARED_PAGES) return -1;

    SharedRegion *r=&regions[id];
    r->valid=1; r->share_id=id;
    r->logical_page=logical_addr/PAGESIZE;
    r->page_count=pages; r->refcount=0;

    for(unsigned i=0;i<pages;i++){
        int f=free_frame();
        if(f<0) return -1;
        r->physical_pages[i]=(unsigned)f;
    }
    return 0;
}

int os_attach_shared(int pid,unsigned id){
    if(pid<0 || pid>=MAX_PROC || id>=MAX_SHARED || !regions[id].valid) return -1;
    SharedRegion *r=&regions[id];
    if(attached[pid][id]) return 0;

    for(unsigned i=0;i<r->page_count;i++)
        page_table[pid][r->logical_page+i]=r->physical_pages[i];

    attached[pid][id]=1;
    r->refcount++;
    return 0;
}

void os_detach_shared(int pid,unsigned id){
    if(pid<0 || pid>=MAX_PROC || id>=MAX_SHARED || !attached[pid][id]) return;
    SharedRegion *r=&regions[id];
    for(unsigned i=0;i<r->page_count;i++)
        page_table[pid][r->logical_page+i]=0xffffffffu;
    attached[pid][id]=0;
    if(r->refcount) r->refcount--;

    if(r->refcount==0){
        for(unsigned i=0;i<r->page_count;i++)
            page_used[r->physical_pages[i]]=0;
        r->valid=0;
    }
}

void os_print_shared_map(void){
    puts("========== SHARED MEMORY MAP ==========");
    for(int i=0;i<MAX_SHARED;i++) if(regions[i].valid){
        SharedRegion *r=&regions[i];
        printf("SHM %u: logical page=%u pages=%u refcount=%d frames=",
               r->share_id,r->logical_page,r->page_count,r->refcount);
        for(unsigned j=0;j<r->page_count;j++)
            printf(" F%u",r->physical_pages[j]);
        putchar('\n');
    }
}
