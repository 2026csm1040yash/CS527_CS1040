#ifndef PROCESSOR_H
#define PROCESSOR_H
void processor_write_shared(int pid,unsigned addr,unsigned value);
unsigned processor_read_shared(int pid,unsigned addr);
#endif
