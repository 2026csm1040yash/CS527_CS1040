# CS527 Lab 5 - Task 8: IPC using Shared Memory

This task demonstrates inter-process communication through shared memory across:
1. Programming model
2. ISA
3. Compiler/binary metadata
4. OS page tables

## Programming model

A shared-memory declaration is supported as:

    shared 1 0x200 0x100

Meaning:
- shared memory id = 1
- logical address = 0x200
- size = 0x100 bytes

A process can then use normal memory syntax on that region:

    x1 = 123
    [0x200] = x1
    x2 = [0x200]

The shared declaration is metadata and does not itself perform an access.

## Binary metadata

The compiler emits a `SHM` metadata record before normal instructions:

    SHM <share_id> <logical_page> <page_count>

The loader/OS reads these records and creates the sharing relationship.

## ISA support

A dedicated `SHM_ATTACH` pseudo-ISA operation is represented in the generated binary as:

    F0 share_id page_count logical_page

It is a privileged OS/loader operation rather than an ordinary arithmetic instruction.

## OS page-table sharing

The OS allocates physical frames for a shared region only once. Each participating process gets page-table entries pointing to the same physical frames. Thus:

    PID 1 logical page -> physical frame X
    PID 2 logical page -> physical frame X

The physical frame is reference counted and is freed only after the last process detaches/exits.

## Test

`tests/shared_memory_demo.txt` demonstrates two processes using the same shared region. The expected output is documented in `tests/EXPECTED.md`.

Build:

    make

or on Windows:

    build_windows.bat

Run:

    ./cs527_lab tests/shared_memory_demo.txt tests/shared_memory_demo.data

The implementation is intentionally small and educational so the four layers can be inspected easily.
