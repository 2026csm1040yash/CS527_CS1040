#ifndef MEMORY_H
#define MEMORY_H
#include <stdint.h>
#define MEMSIZE 8192
#define PAGESIZE 512
extern unsigned char memory[MEMSIZE];
void memory_init(void);
uint32_t mem_read32(uint32_t addr);
void mem_write32(uint32_t addr,uint32_t value);
#endif
