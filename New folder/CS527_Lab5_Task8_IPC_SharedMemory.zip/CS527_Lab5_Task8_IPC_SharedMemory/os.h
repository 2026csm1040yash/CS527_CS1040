#ifndef OS_H
#define OS_H
#define MAX_PROC 4
#define MAX_SHARED 16
#define MAX_SHARED_PAGES 8
typedef struct {
    int valid;
    unsigned share_id;
    unsigned logical_page;
    unsigned page_count;
    unsigned physical_pages[MAX_SHARED_PAGES];
    int refcount;
} SharedRegion;

void os_init(void);
int os_create_shared(unsigned id,unsigned logical_addr,unsigned size);
int os_attach_shared(int pid,unsigned id);
void os_detach_shared(int pid,unsigned id);
void os_print_shared_map(void);
#endif
