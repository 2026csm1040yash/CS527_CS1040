# Expected demonstration

The Task 8 executable should show one shared-memory region and two processes
referring to the same physical frame(s). The essential result is:

    PID 0 wrote 12345 at shared logical address 0x200
    PID 1 read 12345 from shared logical address 0x200

After PID 0 detaches, the region remains allocated because PID 1 still has a
reference. After PID 1 detaches, the physical shared frame is released.

The exact frame number can vary depending on earlier allocations.
