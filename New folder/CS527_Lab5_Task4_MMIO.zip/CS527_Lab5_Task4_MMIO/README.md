# CS527 Lab 5 - Task 4: Memory-Mapped I/O

## Task
Implement memory-mapped I/O in the mini-computer simulator.

The provided CS527 Lab PDFs do not specify an exact MMIO address map. Because the instruction format has one-byte operands and the language limits constants to 0..255, this implementation uses three implementation-defined logical data addresses:

- `0xF0` — Console DATA: write low 8 bits as a character to stdout.
- `0xF4` — Console STATUS: read returns `1` (device ready).
- `0xF8` — Console HEX: write prints the 32-bit value as 8 hexadecimal digits.

MMIO accesses are detected in the processor's memory-read/write path before normal logical-to-physical translation. Thus the device registers do not consume a physical-memory page. Ordinary memory accesses still use the Task 3 page table stored in physical memory.

## Example
```text
x10 = 240
x1 = 72
[x10] = x1
```
prints `H`.

```text
x10 = 244
x1 = [x10]
print x1
```
reads the status register and the process log records `x1 = 1`.

## Build
Linux:
```bash
make
```
Windows PowerShell:
```powershell
.\build_windows.bat
```

## Tests
Linux:
```bash
./tests/run_mmio_test.sh
```
Windows:
```powershell
.\tests\run_mmio_test.bat
```
Expected console output from the first test:
```text
Hi!000000FF
```
The status test writes `x1 = 1` to the process log.

## Retained cumulative features
This package is based on Task 3 and retains integer arithmetic, branches/labels, legacy Read/Write compilation, vector operations, multiprocessing/OS scheduling, paging, and page tables stored in physical memory.
