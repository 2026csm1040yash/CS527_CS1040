#include "compiler.h"
#include "os.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void usage(const char *p) {
    printf("Usage:\n");
    printf("  %s [--rr|--fcfs|--sjf|--priority] [--quantum N] program data [program2 data2 ...]\n", p);
    printf("  Priority mode: add --priorities p1,p2,... (higher number = higher priority).\n");
    printf("  %s                 # interactive shell (Round Robin by default)\n", p);
}

int main(int argc, char **argv) {
    os_init();
    const char *sched="rr"; int quantum=10; int i=1;
    int priorities[32]; int priority_count=0;
    memset(priorities,0,sizeof(priorities));
    while(i<argc) {
        if(!strcmp(argv[i],"--rr")) { sched="rr"; i++; }
        else if(!strcmp(argv[i],"--fcfs")) { sched="fcfs"; i++; }
        else if(!strcmp(argv[i],"--sjf")) { sched="sjf"; i++; }
        else if(!strcmp(argv[i],"--priority")) { sched="priority"; i++; }
        else if(!strcmp(argv[i],"--quantum") && i+1<argc) { quantum=atoi(argv[i+1]); if(quantum<1) quantum=10; i+=2; }
        else if(!strcmp(argv[i],"--priorities") && i+1<argc) {
            char buf[256]; strncpy(buf,argv[i+1],sizeof(buf)-1); buf[sizeof(buf)-1]=0;
            char *tok=strtok(buf,",");
            while(tok && priority_count<32){ priorities[priority_count++]=atoi(tok); tok=strtok(NULL,","); }
            i+=2;
        }
        else break;
    }
    os_set_scheduler(sched,quantum);
    if (i==argc) { os_shell(); os_shutdown(); return 0; }
    if ((argc-i)%2 != 0) { usage(argv[0]); os_shutdown(); return 1; }

    int task_no=0;
    int pids[32];
    for(; i<argc; i+=2) {
        char program_byte[256], data_byte[256];
        snprintf(program_byte,sizeof(program_byte),"task%d.program.byte",task_no);
        snprintf(data_byte,sizeof(data_byte),"task%d.data.byte",task_no);
        int p_ok;
        size_t plen=strlen(argv[i]);
        if(plen>=5 && !strcmp(argv[i]+plen-5,".byte")) {
            FILE *pin=fopen(argv[i],"rb"), *pout=fopen(program_byte,"wb");
            p_ok=(pin&&pout)?0:-1;
            if(p_ok==0){int ch;while((ch=fgetc(pin))!=EOF)fputc(ch,pout);}
            if(pin) fclose(pin);
            if(pout) fclose(pout);
        } else p_ok=compile_program(argv[i],program_byte);
        if(p_ok!=0 || copy_data_file(argv[i+1],data_byte)!=0){
            fprintf(stderr,"Failed to prepare task: %s %s\n",argv[i],argv[i+1]); os_shutdown(); return 1;
        }
        int pid=os_add_task(program_byte,data_byte);
        if(pid<0){ fprintf(stderr,"Failed to load task %d\n",task_no); os_shutdown(); return 1; }
        pids[task_no]=pid;
        if(priority_count>task_no) os_set_task_priority(pid,priorities[task_no]);
        task_no++;
    }
    if(!strcmp(sched,"priority")) {
        if(priority_count < task_no) {
            fprintf(stderr,"Priority mode: provide --priorities p1,p2,... with one value per task. Higher value = higher priority.\n");
            os_shutdown(); return 1;
        }
        for(int k=0;k<task_no;k++) os_set_task_priority(pids[k],priorities[k]);
    }
    os_run(); os_shutdown(); return 0;
}
