@echo off
echo Building CS527 Task 1 - Single Processor Context Switching...
gcc -std=c11 -Wall -Wextra -pedantic main.c compiler.c processor.c memory.c os.c -o cs527_lab_single.exe
if errorlevel 1 (
  echo Build failed.
  exit /b 1
)
echo Build successful: cs527_lab_single.exe
