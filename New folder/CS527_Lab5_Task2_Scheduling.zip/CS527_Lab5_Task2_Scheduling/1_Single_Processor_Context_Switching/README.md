# CS527 Task 1 — Single Processor Multitasking with Context Switching

This version deliberately uses **one physical processor** (`NP=1`) but supports multiple tasks.
Tasks are kept in a ready queue. The scheduler gives each task 10 instructions, then saves the
complete CPU context (PC, x registers, vector registers, flags and page table) into the task's
control block. Before the task gets another turn, that context is restored into the single CPU.

This demonstrates concurrency/time-sharing through context save/restore; it is not simultaneous
hardware parallelism.

## Build on Windows PowerShell

```powershell
gcc --version
.\build_windows.bat
```

Or:
```powershell
gcc -std=c11 -Wall -Wextra -pedantic main.c compiler.c processor.c memory.c os.c -o cs527_lab_single.exe
```

## Run multiple tasks

```powershell
.\cs527_lab_single.exe tests\loop_sum.txt tests\loop_sum.data tests\loop_sum2.txt tests\loop_sum2.data tests\loop_sum3.txt tests\loop_sum3.data
```

The terminal should show repeated `Context restore` and `Context save` messages.

## Architecture retained

The cumulative implementation retains the compiler, arithmetic, branches, memory operations,
vector operations, paging and shell from the later labs. The Lab 5 memory system uses 8192-byte
physical memory and 512-byte pages.
