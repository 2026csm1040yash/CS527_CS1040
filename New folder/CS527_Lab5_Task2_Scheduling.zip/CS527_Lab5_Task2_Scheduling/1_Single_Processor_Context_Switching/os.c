#include "os.h"
#include "processor.h"
#include "compiler.h"
#include "memory.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <conio.h>
#include <direct.h>
#else
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/stat.h>
#endif

#define MAX_TASKS 32
#define TIME_SLICE 10

typedef enum { SCHED_RR, SCHED_FCFS, SCHED_SJF, SCHED_PRIORITY_RR } SchedulerType;
static SchedulerType scheduler_type = SCHED_RR;
static int scheduler_quantum = TIME_SLICE;
static unsigned long long ready_seq_counter = 0;

typedef struct {
    int active;
    int pid;
    int running;
    int priority;
    unsigned long long ready_seq;
    char program[256];
    char data[256];
    /* Saved CPU context: registers, PC, flags and page table. */
    Processor context;
} Task;

static Task tasks[MAX_TASKS];
static int next_pid = 1;
static unsigned char free_pages[NUM_PHYSICAL_PAGES];
static int current_task = -1;

static int getFreePage(void) {
    for (int i=1; i<NUM_PHYSICAL_PAGES; ++i)
        if (!free_pages[i]) { free_pages[i]=1; return i; }
    return -1;
}
static void free_task_memory(Task *t) {
    for (int i=0;i<NUM_LOGICAL_PAGES;i++) {
        int frame=t->context.page_table[i];
        if(frame>0 && frame<NUM_PHYSICAL_PAGES) free_pages[frame]=0;
        t->context.page_table[i]=0;
    }
}
static int count_bytes(const char *file) {
    FILE *f=fopen(file,"r"); if(!f) return -1;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1) { if(x>255){fclose(f);return -1;} n++; }
    fclose(f); return n;
}
static int load_bytes(const char *file, int pid, int fetch) {
    FILE *f=fopen(file,"r"); if(!f) return -1;
    int max=fetch?INST_LOGICAL_SIZE:DATA_LOGICAL_SIZE, n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1) {
        if(n>=max || x>255){fclose(f);return -1;}
        int phys=getPhysicalAddress(0,fetch,n);
        if(phys<0){fclose(f);return -1;}
        physical_memory()[phys]=(unsigned char)x; n++;
    }
    fclose(f); (void)pid; return n;
}
static int allocate_task(Task *t) {
    int ib=count_bytes(t->program), db=count_bytes(t->data);
    if(ib<0||db<0) return -1;
    int ip=(ib+PAGESIZE-1)/PAGESIZE, dp=(db+PAGESIZE-1)/PAGESIZE;
    memset(t->context.page_table,0,sizeof(t->context.page_table));
    for(int i=0;i<ip;i++){int fr=getFreePage(); if(fr<0){free_task_memory(t);return -1;} t->context.page_table[i]=(unsigned char)fr;}
    for(int i=0;i<dp;i++){int fr=getFreePage(); if(fr<0){free_task_memory(t);return -1;} t->context.page_table[INST_LOGICAL_SIZE/PAGESIZE+i]=(unsigned char)fr;}
    /* Temporarily install this task's page table in the single CPU while loading. */
    processors[0].page_table[0]=t->context.page_table[0];
    memcpy(processors[0].page_table,t->context.page_table,sizeof(t->context.page_table));
    if(load_bytes(t->program,0,1)<0 || load_bytes(t->data,0,0)<0){free_task_memory(t);return -1;}
    return 0;
}
static void save_context(Task *t) {
    memcpy(&t->context,&processors[0],sizeof(Processor));
    t->context.used=1; t->context.proc_id=0;
}
static void restore_context(Task *t) {
    memcpy(&processors[0],&t->context,sizeof(Processor));
    processors[0].used=1; processors[0].proc_id=0; processors[0].finished=t->context.finished;
    strncpy(processors[0].log_file,t->context.log_file,sizeof(processors[0].log_file)-1);
    current_task=t->pid;
}
static int write_data(Task *t) {
    int n=count_bytes(t->data); if(n<0)return -1;
    FILE *out=fopen(t->data,"w"); if(!out)return -1;
    for(int i=0;i<n;i++){
        int phys=getPhysicalAddress(0,0,i); if(phys<0){fclose(out);return -1;}
        fprintf(out,"%02X",physical_memory()[phys]); fputc((i%4==3)?'\n':' ',out);
    }
    if(n%4) fputc('\n',out);
    fclose(out);
    return 0;
}
void os_init(void) {
    memset(tasks,0,sizeof(tasks)); memset(free_pages,0,sizeof(free_pages)); memory_reset();
    next_pid=1; ready_seq_counter=0;
    memset(&processors[0],0,sizeof(processors[0])); processors[0].proc_id=0;
#ifdef _WIN32
    _mkdir("logs");
#else
    mkdir("logs",0755);
#endif
}
int os_add_task(const char *program_file,const char *data_file) {
    int s=-1; for(int i=0;i<MAX_TASKS;i++)if(!tasks[i].active){s=i;break;} if(s<0)return -1;
    Task *t=&tasks[s]; memset(t,0,sizeof(*t)); t->active=1; t->pid=next_pid++;
    t->priority = 0;
    t->ready_seq = ready_seq_counter++;
    strncpy(t->program,program_file,255); strncpy(t->data,data_file,255);
    snprintf(t->context.log_file,sizeof(t->context.log_file),"logs/pid%d.log",t->pid);
    t->context.proc_id=0; t->context.used=1;
    if(allocate_task(t)!=0){t->active=0;return -1;}
    /* Initialise a fresh task context, retaining its page table. */
    unsigned char pt[NUM_LOGICAL_PAGES]; memcpy(pt,t->context.page_table,sizeof(pt));
    memset(&t->context,0,sizeof(t->context)); memcpy(t->context.page_table,pt,sizeof(pt));
    t->context.used=1; t->context.proc_id=0;
    snprintf(t->context.log_file,sizeof(t->context.log_file),"logs/pid%d.log",t->pid);
    t->running=0;
    printf("PID %d added to ready queue.\n",t->pid);
    return t->pid;
}
static int active_count(void){int n=0;for(int i=0;i<MAX_TASKS;i++)if(tasks[i].active)n++;return n;}
static Task *find_task(int pid){for(int i=0;i<MAX_TASKS;i++)if(tasks[i].active&&tasks[i].pid==pid)return &tasks[i];return NULL;}
static void run_one(Task *t, int quantum) {
    restore_context(t);
    printf("Context restore: PID %d -> CPU\n",t->pid);
    process_instructions(0,quantum);
    save_context(t);
    printf("Context save:    PID %d <- CPU (PC=%d)\n",t->pid,t->context.pc);
    t->running=0;
    if(t->context.finished){
        write_data(t); free_task_memory(t); t->active=0;
        printf("PID %d finished; context removed.\n",t->pid);
    }
}

static int task_cmp(const Task *a, const Task *b) {
    if (scheduler_type == SCHED_SJF) {
        int ai = count_bytes(a->program), bi = count_bytes(b->program);
        if (ai != bi) return ai < bi ? -1 : 1;
    }
    if (scheduler_type == SCHED_PRIORITY_RR && a->priority != b->priority)
        return a->priority > b->priority ? -1 : 1;
    if (a->ready_seq != b->ready_seq) return a->ready_seq < b->ready_seq ? -1 : 1;
    return a->pid < b->pid ? -1 : (a->pid > b->pid);
}

static Task *select_next_task(void) {
    Task *best=NULL;
    for(int i=0;i<MAX_TASKS;i++) if(tasks[i].active) {
        if(!best || task_cmp(&tasks[i],best)<0) best=&tasks[i];
    }
    return best;
}

static void print_scheduler(void) {
    const char *name = scheduler_type==SCHED_RR ? "Round Robin" :
                       scheduler_type==SCHED_FCFS ? "FCFS" :
                       scheduler_type==SCHED_SJF ? "Shortest Job First" :
                       "Priority Round Robin";
    printf("Scheduler: %s",name);
    if (scheduler_type==SCHED_RR || scheduler_type==SCHED_PRIORITY_RR)
        printf(" (quantum=%d instructions)", scheduler_quantum);
    printf("\n");
}

void os_set_scheduler(const char *name, int quantum) {
    if(!name) return;
    if(!strcmp(name,"rr")) scheduler_type=SCHED_RR;
    else if(!strcmp(name,"fcfs")) scheduler_type=SCHED_FCFS;
    else if(!strcmp(name,"sjf")) scheduler_type=SCHED_SJF;
    else if(!strcmp(name,"priority")) scheduler_type=SCHED_PRIORITY_RR;
    else return;
    if(quantum>0) scheduler_quantum=quantum;
}

int os_set_task_priority(int pid, int priority) {
    Task *t=find_task(pid);
    if(!t) return -1;
    t->priority=priority;
    return 0;
}

void os_run(void) {
    print_scheduler();
    if(scheduler_type == SCHED_RR || scheduler_type == SCHED_PRIORITY_RR) {
        while(active_count()>0) {
            Task *order[MAX_TASKS]; int n=0;
            for(int i=0;i<MAX_TASKS;i++) if(tasks[i].active) order[n++]=&tasks[i];
            for(int a=0;a<n;a++) for(int b=a+1;b<n;b++) {
                if(scheduler_type==SCHED_PRIORITY_RR && task_cmp(order[b],order[a])<0) {
                    Task *tmp=order[a]; order[a]=order[b]; order[b]=tmp;
                }
            }
            if(n==0) break;
            for(int k=0;k<n;k++) if(order[k]->active) run_one(order[k],scheduler_quantum);
        }
    } else if(scheduler_type == SCHED_FCFS) {
        while(active_count()>0) {
            Task *t=select_next_task();
            if(!t) break;
            do { run_one(t,1000); } while(t->active);
        }
    } else { /* SJF: non-preemptive; shortest program first */
        while(active_count()>0) {
            Task *t=select_next_task();
            if(!t) break;
            int remaining=1000000;
            int bytes=count_bytes(t->program);
            if(bytes>0) remaining=bytes/4+2;
            run_one(t,remaining);
            while(t->active) { run_one(t,1000); }
        }
    }
    current_task=-1;
}

static void submit_line(const char *line,int *serial){
    if(!strcmp(line,"exit"))return;
    char p[256],d[256];
    if(sscanf(line,"%255s %255s",p,d)==2){
        char pb[256],db[256]; snprintf(pb,256,"shell_%d.program.byte",*serial);snprintf(db,256,"shell_%d.data.byte",(*serial)++);
        if(compile_program(p,pb)==0&&copy_data_file(d,db)==0)os_add_task(pb,db);
    } else if(line[0]) printf("\nUsage: <program.txt|program.byte> <data.byte>\n");
}
void os_shell(void){
    char line[512]; int len=0,exit_req=0,serial=0;
#ifndef _WIN32
    struct termios oldt,raw; int tty=isatty(STDIN_FILENO);
    if(tty&&tcgetattr(STDIN_FILENO,&oldt)==0){raw=oldt;raw.c_lflag&=(tcflag_t)~(ICANON|ECHO);raw.c_cc[VMIN]=0;raw.c_cc[VTIME]=0;tcsetattr(STDIN_FILENO,TCSANOW,&raw);}
#else
    int tty=1;
#endif
    printf("$ ");fflush(stdout);
    while(!exit_req){
        for(int i=0;i<MAX_TASKS;i++)if(tasks[i].active){run_one(&tasks[i], scheduler_quantum);break;}
#ifndef _WIN32
        if(tty){fd_set set;FD_ZERO(&set);FD_SET(STDIN_FILENO,&set);struct timeval tv={0,0};if(select(STDIN_FILENO+1,&set,NULL,NULL,&tv)>0){char ch;while(read(STDIN_FILENO,&ch,1)==1){if(ch=='\r'||ch=='\n'){line[len]=0;if(!strcmp(line,"exit")){exit_req=1;break;}submit_line(line,&serial);len=0;printf("\n$ ");fflush(stdout);}else if(ch==127&&len){--len;}else if(len<511&&ch>=32&&ch<=126){line[len++]=ch;putchar(ch);fflush(stdout);}}}}
#else
        while(_kbhit()){int ch=_getch();if(ch=='\r'||ch=='\n'){line[len]=0;if(!strcmp(line,"exit")){exit_req=1;break;}submit_line(line,&serial);len=0;printf("\n$ ");fflush(stdout);}else if(ch==8&&len)--len;else if(len<511&&ch>=32&&ch<=126){line[len++]=(char)ch;putchar(ch);fflush(stdout);}}
#endif
        if(!tty&&active_count()==0){if(!fgets(line,sizeof(line),stdin))break;line[strcspn(line,"\r\n")]=0;if(!strcmp(line,"exit"))break;submit_line(line,&serial);printf("$ ");fflush(stdout);}
    }
#ifndef _WIN32
    if(tty)tcsetattr(STDIN_FILENO,TCSANOW,&oldt);
#endif
}
void os_shutdown(void){current_task=-1;}
