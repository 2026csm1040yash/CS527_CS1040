# CS527 Lab 5 - Task 2: Extend Round Robin to More Interesting Scheduling Schemes

This folder extends the single-processor context-switching implementation with selectable scheduling policies.

## Scheduling schemes

1. **Round Robin (`--rr`)**
   - Default policy.
   - Each ready task gets a fixed instruction quantum.
   - Default quantum is 10; use `--quantum N` to change it.

2. **FCFS (`--fcfs`)**
   - First-Come, First-Served.
   - Non-preemptive: the first task runs until it finishes, then the next task runs.

3. **SJF (`--sjf`)**
   - Shortest Job First.
   - Non-preemptive.
   - Program bytecode length is used as the job-size estimate.

4. **Priority Round Robin (`--priority`)**
   - Higher numeric priority runs first.
   - Tasks with the same priority receive round-robin time slices.
   - Supply one priority per task using `--priorities p1,p2,...`.

## Windows PowerShell

```powershell
.\build_windows.bat

# Round Robin, quantum = 5
.\cs527_lab_single.exe --rr --quantum 5 tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data

# FCFS
.\cs527_lab_single.exe --fcfs tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data

# SJF
.\cs527_lab_single.exe --sjf tests\task2_short.txt tests\task2_short.data tests\task2_long.txt tests\task2_long.data

# Priority Round Robin: PID 1 priority=1, PID 2 priority=10
.\cs527_lab_single.exe --priority --quantum 5 --priorities 1,10 tests\priority1.txt tests\priority1.data tests\priority2.txt tests\priority2.data
```

## Linux

```bash
make
./cs527_lab_single --rr --quantum 5 tests/task1.txt tests/task1.data tests/task2.txt tests/task2.data
./cs527_lab_single --fcfs tests/task1.txt tests/task1.data tests/task2.txt tests/task2.data
./cs527_lab_single --sjf tests/task2_short.txt tests/task2_short.data tests/task2_long.txt tests/task2_long.data
./cs527_lab_single --priority --quantum 5 --priorities 1,10 tests/priority1.txt tests/priority1.data tests/priority2.txt tests/priority2.data
```

## What to observe

The output prints `Context restore` and `Context save` messages. This makes the scheduling policy visible during the viva/demo.

The Lab 5 handout specifies round-robin scheduling with a fixed instruction slice. The FCFS, SJF and Priority Round Robin policies are additional implementation extensions for this task.
