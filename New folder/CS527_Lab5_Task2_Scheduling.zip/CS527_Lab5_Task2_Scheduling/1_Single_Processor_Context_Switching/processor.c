#define _POSIX_C_SOURCE 200809L
#include "processor.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#ifdef _WIN32
#include <windows.h>
#endif

Processor processors[NP];

static void update_flags_add(Processor *p, uint32_t a, uint32_t b, uint32_t r) {
    uint64_t ur = (uint64_t)a + (uint64_t)b;
    int32_t sa = (int32_t)a, sb = (int32_t)b, sr = (int32_t)r;
    p->z = (r == 0);
    p->n = ((r >> 31) & 1);
    p->c = (ur > 0xFFFFFFFFULL);
    p->v = ((sa >= 0 && sb >= 0 && sr < 0) || (sa < 0 && sb < 0 && sr >= 0));
}

static void update_flags_sub(Processor *p, uint32_t a, uint32_t b, uint32_t r) {
    int32_t sa = (int32_t)a, sb = (int32_t)b, sr = (int32_t)r;
    p->z = (r == 0);
    p->n = ((r >> 31) & 1);
    p->c = (a > b);
    p->v = ((sa < 0 && sb >= 0 && sr >= 0) || (sa >= 0 && sb < 0 && sr < 0));
}

int getPhysicalAddress(int proc_id, int isFetch, int logical_address) {
    if (proc_id < 0 || proc_id >= NP || logical_address < 0) return -1;
    int index = isFetch ? logical_address / PAGESIZE
                        : logical_address / PAGESIZE + INST_LOGICAL_SIZE / PAGESIZE;
    if (index < 0 || index >= NUM_LOGICAL_PAGES) return -1;
    int offset = logical_address % PAGESIZE;
    int frame = processors[proc_id].page_table[index];
    if (frame == 0) return -1; /* frame 0 is reserved */
    int physical = frame * PAGESIZE + offset;
    if (physical < 0 || physical >= MEMSIZE) return -1;
    return physical;
}

void processor_reset(int pid) {
    Processor *p = &processors[pid];
    memset(p->regs, 0, sizeof(p->regs));
    memset(p->vregs, 0, sizeof(p->vregs));
    p->pc = 0;
    p->z = p->n = p->c = p->v = 0;
    p->finished = 0;
    FILE *f = fopen(p->log_file, "a");
    if (f) { fprintf(f, "Process %d started\n", pid); fclose(f); }
}

static uint32_t load32(int phys) {
    unsigned char *m = physical_memory();
    return ((uint32_t)m[phys]) |
           ((uint32_t)m[phys+1] << 8) |
           ((uint32_t)m[phys+2] << 16) |
           ((uint32_t)m[phys+3] << 24);
}

static void store32(int phys, uint32_t x) {
    unsigned char *m = physical_memory();
    m[phys] = (unsigned char)(x & 0xFF);
    m[phys+1] = (unsigned char)((x >> 8) & 0xFF);
    m[phys+2] = (unsigned char)((x >> 16) & 0xFF);
    m[phys+3] = (unsigned char)((x >> 24) & 0xFF);
}

static int read32_logical(int pid, int addr, uint32_t *out) {
    int phys = getPhysicalAddress(pid, 0, addr);
    if (phys < 0 || phys + 3 >= MEMSIZE) return -1;
    *out = load32(phys);
    return 0;
}

static int write32_logical(int pid, int addr, uint32_t value) {
    int phys = getPhysicalAddress(pid, 0, addr);
    if (phys < 0 || phys + 3 >= MEMSIZE) return -1;
    store32(phys, value);
    return 0;
}

int processor_step(int pid) {
    Processor *p = &processors[pid];
    if (!p->used || p->finished) return 0;

    int phys = getPhysicalAddress(pid, 1, p->pc);
    if (phys < 0 || phys + 3 >= MEMSIZE) {
        fprintf(stderr, "PID %d: invalid instruction address %d\n", pid, p->pc);
        p->finished = 1; return -1;
    }

    unsigned char *m = physical_memory();
    unsigned op = m[phys], dest = m[phys+1], src1 = m[phys+2], src2 = m[phys+3];
    int old_pc = p->pc;
    p->pc += 4;

    if (op == 0x00) { p->finished = 1; return 0; }

    uint32_t a, b, r;
    int addr;

    switch (op) {
    case 0x01: /* add reg */
        a=p->regs[src1]; b=p->regs[src2]; r=a+b; p->regs[dest]=r; update_flags_add(p,a,b,r); break;
    case 0x02:
        a=p->regs[src1]; b=p->regs[src2]; r=a-b; p->regs[dest]=r; update_flags_sub(p,a,b,r); break;
    case 0x03:
        p->regs[dest]=p->regs[src1]*p->regs[src2]; break;
    case 0x04:
        if (p->regs[src2]==0) { fprintf(stderr,"PID %d: divide by zero\n",pid); p->finished=1; break; }
        p->regs[dest]=p->regs[src1]/p->regs[src2]; break;
    case 0x09:
        a=p->regs[src1]; b=src2; r=a+b; p->regs[dest]=r; update_flags_add(p,a,b,r); break;
    case 0x0A:
        a=p->regs[src1]; b=src2; r=a-b; p->regs[dest]=r; update_flags_sub(p,a,b,r); break;
    case 0x0B: p->regs[dest]=p->regs[src1]*src2; break;
    case 0x0C:
        if (src2==0) { fprintf(stderr,"PID %d: divide by zero\n",pid); p->finished=1; break; }
        p->regs[dest]=p->regs[src1]/src2; break;
    case 0x05:
        addr=(int)p->regs[src2]; if(read32_logical(pid,addr,&r)) {p->finished=1;break;} p->regs[dest]=r; break;
    case 0x0D:
        addr=src2; if(read32_logical(pid,addr,&r)) {p->finished=1;break;} p->regs[dest]=r; break;
    case 0x06:
        addr=(int)p->regs[src1]; if(write32_logical(pid,addr,p->regs[src2])) p->finished=1; break;
    case 0x0E:
        /* Constant-address memory write. For legacy Write and bracket
           constant syntax, src1 carries the logical address and src2 the
           source integer register. */
        addr=src1; if(write32_logical(pid,addr,p->regs[src2])) p->finished=1; break;
    case 0x0F: p->regs[dest]=src2; break;
    case 0x08: {
        FILE *f=fopen(p->log_file,"a");
        if(f){fprintf(f,"Process id: x%u : %08X\n",src2,p->regs[src2]);fclose(f);}
        break;
    }

    case 0x21: case 0x22: case 0x23: {
        int vd=dest, va=src1, vb=src2;
        for(int i=0;i<8;i++){
            if(op==0x21)p->vregs[vd][i]=p->vregs[va][i]+p->vregs[vb][i];
            else if(op==0x22)p->vregs[vd][i]=p->vregs[va][i]-p->vregs[vb][i];
            else p->vregs[vd][i]=p->vregs[va][i]*p->vregs[vb][i];
        } break;
    }
    case 0x29: case 0x2A: case 0x2B: {
        int vd=dest, va=src1, k=src2;
        for(int i=0;i<8;i++){
            if(op==0x29)p->vregs[vd][i]=p->vregs[va][i]+k;
            else if(op==0x2A)p->vregs[vd][i]=p->vregs[va][i]-k;
            else p->vregs[vd][i]=p->vregs[va][i]*k;
        } break;
    }
    case 0x25: case 0x2C: {
        int vd=dest;
        addr = (op==0x25) ? (int)p->regs[src2] : (int)src2;
        for(int i=0;i<8;i++,addr+=4){
            if(read32_logical(pid,addr,&r)) {p->finished=1;break;}
            p->vregs[vd][i]=r;
        } break;
    }
    case 0x26: case 0x2E: {
        int vs=src2;
        addr = (op==0x26) ? (int)p->regs[src1] : (int)src1;
        for(int i=0;i<8;i++,addr+=4){
            if(write32_logical(pid,addr,p->vregs[vs][i])) {p->finished=1;break;}
        } break;
    }

    default:
        if (op >= 0x10 && op <= 0x1E) {
            int take=0;
            switch(op-0x10){
            case 0: take=p->z; break; case 1: take=!p->z; break;
            case 2: take=p->c; break; case 3: take=!p->c; break;
            case 4: take=p->n; break; case 5: take=!p->n; break;
            case 6: take=p->v; break; case 7: take=!p->v; break;
            case 8: take=p->c && !p->z; break; case 9: take=!p->c || p->z; break;
            case 10: take=p->n==p->v; break; case 11: take=p->n!=p->v; break;
            case 12: take=!p->z && (p->n==p->v); break;
            case 13: take=p->z || (p->n!=p->v); break;
            case 14: take=1; break;
            }
            if(take) p->pc = old_pc + (int8_t)src2;
        } else {
            fprintf(stderr,"PID %d: unknown opcode %02X\n",pid,op);
            p->finished=1;
        }
    }
#ifdef _WIN32
    Sleep(1);
#else
    struct timespec ts = {0, 10000};
    nanosleep(&ts, NULL);
#endif
    return 1;
}

void process_instructions(int pid, int instruction_count) {
    for(int i=0;i<instruction_count && !processors[pid].finished;i++)
        processor_step(pid);
}
