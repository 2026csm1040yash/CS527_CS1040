#ifndef OS_H
#define OS_H

/* Task 1: one physical processor, multiple software tasks via context switching. */
#define NP 1
void os_init(void);
int os_add_task(const char *program_file, const char *data_file);
void os_run(void);
void os_set_scheduler(const char *name, int quantum);
int os_set_task_priority(int pid, int priority);
void os_shell(void);
void os_shutdown(void);
#endif
