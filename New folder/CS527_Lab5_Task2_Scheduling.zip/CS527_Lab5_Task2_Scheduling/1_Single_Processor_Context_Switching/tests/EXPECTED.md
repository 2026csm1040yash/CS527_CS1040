# Expected results

## legacy_lab1
Input values are 2 and 5. `x3 = x1 + x2`, so the value written at address 8 is 7.

```text
07 00 00 00
```

The log contains:

```text
Process id: x3 : 00000007
```

## branch_conditions
The program computes `10 - 3`, takes `BGT`, and prints:

```text
Process id: x6 : 00000007
```

## sum_arrays
The result for the eight elements is:

```text
11 22 33 44 55 66 77 88
```

as decimal values 11, 22, 33, 44, 55, 66, 77, 88.

## vector_math
The vector arithmetic test should complete without an execution error. Inspect `logs/pid*.log` for Print output.

## loop_sum
The final stored value is decimal 150:

```text
96 00 00 00
```

## fir
For N=10, input 1..10, and weights `[1,2,1,0,0,0,0,0]`, there are `N-8 = 2` outputs. Expected output values at logical addresses `0x100` and `0x104` are:

```text
08 00 00 00
0C 00 00 00
```

The final Print should show:

```text
Process id: x8 : 0000000C
```

## multiprocess
Five tasks are submitted while `NP=4`. The terminal should show four initial processor assignments, PID 5 entering the waiting queue, and PID 5 being loaded after a processor becomes free.
