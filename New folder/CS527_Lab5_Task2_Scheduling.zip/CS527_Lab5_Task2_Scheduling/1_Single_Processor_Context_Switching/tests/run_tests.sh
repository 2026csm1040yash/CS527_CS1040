#!/bin/sh
set -e
cd "$(dirname "$0")/.."
make
./cs527_lab tests/legacy_lab1.txt tests/legacy_lab1.data
./cs527_lab tests/branch_conditions.txt tests/branch_conditions.data
./cs527_lab tests/sum_arrays.txt tests/sum_arrays.data
./cs527_lab tests/vector_math.txt tests/vector_math.data
./cs527_lab tests/loop_sum.txt tests/loop_sum.data
./cs527_lab tests/fir.txt tests/fir.data
./tests/multiprocess.sh
printf '\nAll cumulative CS527 Lab 1-5 tests completed.\n'
