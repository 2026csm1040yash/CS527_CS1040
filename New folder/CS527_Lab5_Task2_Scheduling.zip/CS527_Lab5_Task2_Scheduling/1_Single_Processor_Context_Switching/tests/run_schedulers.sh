#!/bin/sh
set -e
make
./cs527_lab_single --rr --quantum 5 tests/task1.txt tests/task1.data tests/task2.txt tests/task2.data
./cs527_lab_single --fcfs tests/task1.txt tests/task1.data tests/task2.txt tests/task2.data
./cs527_lab_single --sjf tests/task2_short.txt tests/task2_short.data tests/task2_long.txt tests/task2_long.data
./cs527_lab_single --priority --quantum 5 tests/priority1.txt tests/priority1.data tests/priority2.txt tests/priority2.data
