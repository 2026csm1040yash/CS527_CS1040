# Expected scheduling behavior

Exact PC values can vary with the test program, but the ordering should demonstrate:

- **RR:** PID 1 and PID 2 alternate for the selected quantum.
- **FCFS:** PID 1 completes before PID 2 starts.
- **SJF:** the shorter program starts before the longer program.
- **Priority RR:** with priorities `1,10`, PID 2 starts before PID 1 and receives the first quantum; subsequent quanta are shared according to the priority ordering.
