#!/bin/sh
set -e
./cs527_lab \
  tests/loop_sum.txt tests/loop_sum.data \
  tests/loop_sum.txt tests/loop_sum.data \
  tests/loop_sum.txt tests/loop_sum.data \
  tests/loop_sum.txt tests/loop_sum.data \
  tests/loop_sum.txt tests/loop_sum.data
