# CS527 cumulative test cases

- `legacy_lab1.*`: Lab 1 `Read`/`Write` syntax plus arithmetic and Print.
- `branch_conditions.*`: labels, subtraction flags, BEQ/BGT and Print.
- `sum_arrays.*`: vector array addition.
- `fir.*`: vector FIR implementation for N=10. It uses vector load, vector multiply, vector store, then scalar reduction of the eight products.
- `loop_sum.*`: integer loop, memory access and branches.
- `multiprocess.sh`: five tasks to exercise four processors plus the waiting queue.

The FIR data layout follows the Lab 5 specification: N at 0x0, eight weights at 0x20, input immediately after the 32-byte weight block, and output at 0x100.
