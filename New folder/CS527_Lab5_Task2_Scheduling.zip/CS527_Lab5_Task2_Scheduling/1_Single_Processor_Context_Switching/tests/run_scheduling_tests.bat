@echo off
call build_windows.bat
if errorlevel 1 exit /b 1

echo ===== ROUND ROBIN =====
cs527_lab_single.exe --rr --quantum 5 tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data

echo ===== FCFS =====
cs527_lab_single.exe --fcfs tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data

echo ===== SJF =====
cs527_lab_single.exe --sjf tests\task2_short.txt tests\task2_short.data tests\task2_long.txt tests\task2_long.data

echo ===== PRIORITY ROUND ROBIN =====
cs527_lab_single.exe --priority --quantum 5 --priorities 1,10 tests\priority1.txt tests\priority1.data tests\priority2.txt tests\priority2.data
