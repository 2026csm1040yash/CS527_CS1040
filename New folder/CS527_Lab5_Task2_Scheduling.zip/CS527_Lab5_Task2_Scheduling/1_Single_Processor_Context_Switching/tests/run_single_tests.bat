@echo off
cs527_lab_single.exe tests\task1.txt tests\task1.data tests\task2.txt tests\task2.data tests\task3.txt tests\task3.data
