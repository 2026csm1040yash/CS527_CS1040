#include "os.h"
#include "processor.h"
#include "compiler.h"
#include "memory.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#endif
#ifdef _WIN32
#include <conio.h>
#else
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#endif

#define MAX_TASKS 32

typedef struct {
    int active;
    int pid;
    int proc_id;
    char program[256];
    char data[256];
    int page_table_frame;
    unsigned long instructions, memory_reads, memory_writes, time_slices;
    unsigned long long cycles; unsigned long tlb_hits, tlb_misses, cache_hits, cache_misses;
} Task;

static Task tasks[MAX_TASKS];
static int next_pid = 1;
static unsigned char free_pages[NUM_PHYSICAL_PAGES];

static int getFreePage(void) {
    for (int i=1; i<NUM_PHYSICAL_PAGES; ++i) {
        if (!free_pages[i]) {
            free_pages[i]=1;
            return i;
        }
    }
    return -1;
}

static void free_task_memory(int proc_id, int pt_frame) {
    if (pt_frame > 0 && pt_frame < NUM_PHYSICAL_PAGES) {
        unsigned char *m=physical_memory();
        int base=pt_frame*PAGESIZE;
        for(int i=0;i<NUM_LOGICAL_PAGES;i++){int frame=m[base+i]; if(frame>0&&frame<NUM_PHYSICAL_PAGES) free_pages[frame]=0; m[base+i]=0;}
        free_pages[pt_frame]=0;
    }
    processors[proc_id].page_table_frame=-1;
}

static void dump_page_table(int pid);

static int count_data_bytes(const char *file) {
    FILE *f=fopen(file,"r"); if(!f) return -1;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1) { if(x>255){fclose(f);return -1;} n++; }
    fclose(f); return n;
}

static int load_bytes_to_pages(const char *file, int proc_id, int is_instruction) {
    FILE *f=fopen(file,"r");
    if(!f) {perror(file);return -1;}
    int max = is_instruction ? INST_LOGICAL_SIZE : DATA_LOGICAL_SIZE;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1){
        if(n>=max || x>255){fclose(f);return -1;}
        int logical=n;
        int phys=getPhysicalAddress(proc_id,is_instruction,logical);
        if(phys<0){fclose(f);return -1;}
        physical_memory()[phys]=(unsigned char)x;
        n++;
    }
    fclose(f);
    return n;
}

static int write_data_file(const char *file, int proc_id) {
    int n = count_data_bytes(file);
    if (n < 0) return -1;
    FILE *out = fopen(file, "w");
    if (!out) { perror(file); return -1; }
    unsigned char *m = physical_memory();
    for (int i = 0; i < n; ++i) {
        int phys = getPhysicalAddress(proc_id, 0, i);
        if (phys < 0) { fclose(out); return -1; }
        fprintf(out, "%02X", m[phys]);
        if ((i + 1) % 4 == 0) fputc('\n', out);
        else fputc(' ', out);
    }
    if (n % 4) fputc('\n', out);
    fclose(out);
    return 0;
}

static int allocate_for_task(int proc_id,const char*program,const char*data,int*pt_out){
    int ib=count_data_bytes(program),db=count_data_bytes(data); if(ib<0||db<0)return -1;
    int ip=(ib+PAGESIZE-1)/PAGESIZE, dp=(db+PAGESIZE-1)/PAGESIZE;
    if(ip>INST_LOGICAL_SIZE/PAGESIZE||dp>DATA_LOGICAL_SIZE/PAGESIZE)return -1;
    int pt=getFreePage(); if(pt<0)return -1; processors[proc_id].page_table_frame=pt;
    unsigned char*m=physical_memory(); int base=pt*PAGESIZE; memset(m+base,0,PAGESIZE);
    for(int i=0;i<ip;i++){int f=getFreePage();if(f<0){free_task_memory(proc_id,pt);return -1;}m[base+i]=(unsigned char)f;}
    for(int i=0;i<dp;i++){int f=getFreePage();if(f<0){free_task_memory(proc_id,pt);return -1;}m[base+INST_LOGICAL_SIZE/PAGESIZE+i]=(unsigned char)f;}
    if(load_bytes_to_pages(program,proc_id,1)<0||load_bytes_to_pages(data,proc_id,0)<0){free_task_memory(proc_id,pt);return -1;}
    *pt_out=pt; return 0;
}

void os_init(void) {
    memset(tasks,0,sizeof(tasks));
    memset(free_pages,0,sizeof(free_pages));
    memory_reset();
    for(int p=0;p<NP;p++){
        memset(&processors[p],0,sizeof(processors[p]));
        processors[p].proc_id=p; processors[p].page_table_frame=-1;
        snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/process%d.log",p);
    }
#ifdef _WIN32
    _mkdir("logs");
#else
    mkdir("logs", 0755);
#endif
}

int os_add_task(const char *program_file, const char *data_file) {
    int slot=-1;
    for(int i=0;i<NP;i++) if(!processors[i].used){slot=i;break;}

    int t=-1;
    for(int i=0;i<MAX_TASKS;i++) if(!tasks[i].active){t=i;break;}
    if(t<0) return -1;

    if(slot<0) {
        /* Four processors are busy: retain the task in the waiting queue.
           It will be loaded when a processor becomes free. */
        tasks[t].active=1;
        tasks[t].pid=next_pid++;
        tasks[t].proc_id=-1;
        strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
        strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);
        printf("PID %d placed in waiting queue.\n",tasks[t].pid);
        return tasks[t].pid;
    }

    tasks[t].active=1;
    tasks[t].pid=next_pid++;
    tasks[t].proc_id=slot;
    strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
    strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);

    processors[slot].used=1;
    processors[slot].proc_id=slot;
    int pt_frame=-1;
    if(allocate_for_task(slot,program_file,data_file,&pt_frame)!=0){
        processors[slot].used=0; tasks[t].active=0; return -1;
    }
    tasks[t].page_table_frame=pt_frame;
    snprintf(processors[slot].log_file,sizeof(processors[slot].log_file),"logs/pid%d.log",tasks[t].pid);
    processor_reset(slot);
    printf("Loaded PID %d on processor %d.\n",tasks[t].pid,slot);
    dump_page_table(slot);
    return tasks[t].pid;
}

static int active_count(void) {
    int n=0;
    for(int i=0;i<MAX_TASKS;i++) if(tasks[i].active)n++;
    return n;
}

static void release_finished(void) {
    for(int i=0;i<MAX_TASKS;i++){
        if(tasks[i].active && tasks[i].proc_id>=0){
            int p=tasks[i].proc_id;
            if(processors[p].finished){
                printf("PID %d finished on processor %d.\n",tasks[i].pid,p);
                tasks[i].instructions=processors[p].instructions_executed;
                tasks[i].memory_reads=processors[p].memory_reads;
                tasks[i].memory_writes=processors[p].memory_writes;
                tasks[i].time_slices=processors[p].time_slices;
                tasks[i].cycles=processors[p].cycles; tasks[i].tlb_hits=processors[p].tlb_hits; tasks[i].tlb_misses=processors[p].tlb_misses; tasks[i].cache_hits=processors[p].cache_hits; tasks[i].cache_misses=processors[p].cache_misses;
                write_data_file(tasks[i].data,p);
                free_task_memory(p,tasks[i].page_table_frame);
                processors[p].used=0;
                tasks[i].active=0;
            }
        }
    }

    /* Fill newly free processors from the waiting queue. */
    for(int p=0;p<NP;p++){
        if(processors[p].used) continue;
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id==-1){
                tasks[i].proc_id=p;
                processors[p].used=1;
                int pt_frame=-1;
                if(allocate_for_task(p,tasks[i].program,tasks[i].data,&pt_frame)!=0){
                    tasks[i].active=0; processors[p].used=0;
                    continue;
                }
                tasks[i].page_table_frame=pt_frame;
                snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/pid%d.log",tasks[i].pid);
                processor_reset(p);
                printf("Loaded waiting PID %d on processor %d.\n",tasks[i].pid,p);
                dump_page_table(p);
                break;
            }
        }
    }
}

static void dump_page_table(int pid){
    int pt=processors[pid].page_table_frame; unsigned char*m=physical_memory();
    printf("  Page table: physical frame %d (physical address %d)\n",pt,pt*PAGESIZE);
    printf("  Entries: "); for(int i=0;i<NUM_LOGICAL_PAGES;i++) printf("P%d->F%u%s",i,m[pt*PAGESIZE+i],i==NUM_LOGICAL_PAGES-1?"":"  "); printf("\n");
}

void os_run(void) {
    while(active_count()>0){
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id>=0){
                process_instructions(tasks[i].proc_id,10);
            }
        }
        release_finished();
    }
}

static void submit_shell_line(const char *line, int *serial) {
    if (strcmp(line, "exit") == 0) return;
    char program[256], data[256];
    if (sscanf(line, "%255s %255s", program, data) == 2) {
        char pbyte[256], dbyte[256];
        snprintf(pbyte, sizeof(pbyte), "shell_%d.program.byte", *serial);
        snprintf(dbyte, sizeof(dbyte), "shell_%d.data.byte", (*serial)++);
        if (compile_program(program, pbyte) == 0 && copy_data_file(data, dbyte) == 0)
            os_add_task(pbyte, dbyte);
    } else if (line[0] != '\0') {
        printf("\nUsage: <program.txt|program.byte> <data.byte>\n");
    }
}

void os_shell(void) {
    char line[512];
    int len = 0, serial = 0, exit_requested = 0;

#ifndef _WIN32
    struct termios oldt, raw;
    int have_tty = isatty(STDIN_FILENO);
    if (have_tty && tcgetattr(STDIN_FILENO, &oldt) == 0) {
        raw = oldt;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    }
#else
    int have_tty = 1;
#endif

    printf("$ "); fflush(stdout);
    while (!exit_requested) {
        /* One scheduler time slice, then poll the shell. */
        int any = active_count();
        if (any > 0) {
            for (int i = 0; i < MAX_TASKS; ++i)
                if (tasks[i].active && tasks[i].proc_id >= 0)
                    process_instructions(tasks[i].proc_id, 10);
            release_finished();
        }

#ifndef _WIN32
        fd_set set;
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        struct timeval tv = {0, 0};
        int ready = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
        if (ready > 0 && FD_ISSET(STDIN_FILENO, &set)) {
            char ch;
            while (read(STDIN_FILENO, &ch, 1) == 1) {
                if (ch == '\r' || ch == '\n') {
                    line[len] = '\0';
                    if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                    submit_shell_line(line, &serial);
                    len = 0;
                    printf("\n$ "); fflush(stdout);
                } else if (ch == 127 || ch == '\b') {
                    if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
                } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                    line[len++] = ch;
                    putchar(ch); fflush(stdout);
                }
            }
        }
#else
        while (_kbhit()) {
            int ch = _getch();
            if (ch == '\r' || ch == '\n') {
                line[len] = '\0';
                if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                submit_shell_line(line, &serial);
                len = 0;
                printf("\n$ "); fflush(stdout);
            } else if (ch == 8) {
                if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
            } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                line[len++] = (char)ch;
                putchar(ch); fflush(stdout);
            }
        }
#endif

        if (!have_tty && active_count() == 0) {
            /* For redirected stdin, fall back to blocking line input. */
            if (fgets(line, sizeof(line), stdin) == NULL) break;
            line[strcspn(line, "\r\n")] = '\0';
            if (strcmp(line, "exit") == 0) break;
            submit_shell_line(line, &serial);
            printf("$ "); fflush(stdout);
        }

        if (active_count() == 0 && !have_tty) break;
    }

#ifndef _WIN32
    if (have_tty) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
    /* After 'exit', the shell stops accepting new tasks; existing tasks continue. */
    os_run();
    putchar('\n');
}


void os_print_memory_map(void) {
    unsigned char *m = physical_memory();
    printf("\n========== PHYSICAL MEMORY MAP ==========""\n");
    printf("Frame size: %d bytes | Physical memory: %d bytes | Frames: %d\n", PAGESIZE, MEMSIZE, NUM_PHYSICAL_PAGES);
    for (int p = 0; p < NP; ++p) {
        if (!processors[p].used && processors[p].page_table_frame < 0) continue;
        int pt = processors[p].page_table_frame;
        printf("Processor %d: PID-context, page-table frame=%d\n", p, pt);
        if (pt >= 0) {
            int base = pt * PAGESIZE;
            printf("  PT physical range: 0x%04X-0x%04X\n", base, base + PAGESIZE - 1);
            printf("  Instruction: ");
            int found = 0;
            for (int i=0;i<INST_LOGICAL_SIZE/PAGESIZE;i++) if (m[base+i]) { printf("F%d ",m[base+i]); found=1; }
            if (!found) printf("none");
            printf("\n  Data: "); found=0;
            int db=INST_LOGICAL_SIZE/PAGESIZE;
            for (int i=0;i<DATA_LOGICAL_SIZE/PAGESIZE;i++) if (m[base+db+i]) { printf("F%d ",m[base+db+i]); found=1; }
            if (!found) printf("none");
            printf("\n");
        }
    }
    printf("Free frames: ");
    int n=0; for(int f=1;f<NUM_PHYSICAL_PAGES;f++) if(!free_pages[f]) { printf("F%d ",f); n++; }
    printf("(%d free)\n",n);
    printf("=========================================\n");
}

void os_print_performance(void) {
    printf("\n========== PROCESS PERFORMANCE ==========""\n");
    printf("%-6s %-6s %-12s %-10s %-10s %-8s %-10s %-10s %-10s\n", "PID", "CPU", "Cycles", "TLBHit", "TLBMiss", "CacheHit", "CacheMiss", "MemRead", "MemWrite");
    for (int i=0;i<MAX_TASKS;i++) {
        if (tasks[i].pid <= 0) continue;
        int cpu=tasks[i].proc_id;
        printf("%-6d %-6d %-12llu %-10lu %-10lu %-8lu %-10lu %-10lu %-10lu\n", tasks[i].pid,cpu,tasks[i].cycles,tasks[i].tlb_hits,tasks[i].tlb_misses,tasks[i].cache_hits,tasks[i].cache_misses,tasks[i].memory_reads,tasks[i].memory_writes);
    }
    printf("==========================================\n");
}

void os_print_utilities(void) {
    printf("\nCS527 Utilities:\n");
    printf("  memory-map   : physical frames/page-table mappings\n");
    printf("  performance  : instructions, memory operations and time slices\n");
}

void os_shutdown(void) {
    for(int i=0;i<NP;i++){
        if(processors[i].used) free_task_memory(i, processors[i].page_table_frame);
        processors[i].used=0;
    }
}
