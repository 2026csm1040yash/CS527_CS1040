#include "compiler.h"
#include "processor.h"
#include "os.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void usage(const char *p) {
    printf("Usage:\n");
    printf("  %s program.txt data.byte [program2.txt data2.byte ...]\n", p);
    printf("  %s --utils\n", p);
    printf("  %s --memory-map program.txt data.byte [program2.txt data2.byte ...]\n", p);
    printf("  %s --performance program.txt data.byte [program2.txt data2.byte ...]\n", p);
    printf("  %s --all-utils program.txt data.byte [program2.txt data2.byte ...]\n", p);
    printf("  %s --no-cache-tlb ...    # baseline timing without cache/TLB\n", p);
    printf("  %s --timing ...          # print timing/cache/TLB statistics\n", p);
    printf("  %s                 # interactive shell\n", p);
}

int main(int argc, char **argv) {
    os_init();

    int util_mem=0, util_perf=0;
    if (argc>1 && strcmp(argv[1],"--no-cache-tlb")==0) { processor_set_cache_tlb_enabled(0); argc--; argv++; }
    if (argc>1 && strcmp(argv[1],"--timing")==0) { util_perf=1; argc--; argv++; }
    if (argc>1 && strcmp(argv[1],"--utils")==0) { os_print_utilities(); os_shutdown(); return 0; }
    if (argc>1 && strcmp(argv[1],"--memory-map")==0) { util_mem=1; argc--; argv++; }
    else if (argc>1 && strcmp(argv[1],"--performance")==0) { util_perf=1; argc--; argv++; }
    else if (argc>1 && strcmp(argv[1],"--all-utils")==0) { util_mem=util_perf=1; argc--; argv++; }

    if (argc == 1) {
        os_shell();
        os_shutdown();
        return 0;
    }

    if ((argc-1)%2 != 0) {
        usage(argv[0]);
        os_shutdown();
        return 1;
    }

    int task_no=0;
    for(int i=1;i<argc;i+=2){
        char program_byte[256], data_byte[256];
        snprintf(program_byte,sizeof(program_byte),"task%d.program.byte",task_no);
        snprintf(data_byte,sizeof(data_byte),"task%d.data.byte",task_no);
        int p_ok;
        size_t plen = strlen(argv[i]);
        if (plen >= 5 && strcmp(argv[i] + plen - 5, ".byte") == 0) {
            FILE *pin = fopen(argv[i], "rb");
            FILE *pout = fopen(program_byte, "wb");
            p_ok = (pin && pout) ? 0 : -1;
            if (p_ok == 0) {
                int ch; while ((ch = fgetc(pin)) != EOF) fputc(ch, pout);
            }
            if (pin) fclose(pin);
            if (pout) fclose(pout);
        } else {
            p_ok = compile_program(argv[i], program_byte);
        }
        if(p_ok!=0 || copy_data_file(argv[i+1],data_byte)!=0){
            fprintf(stderr,"Failed to prepare task: %s %s\n",argv[i],argv[i+1]);
            os_shutdown();
            return 1;
        }
        if(os_add_task(program_byte,data_byte)<0){
            fprintf(stderr,"Failed to load task %d\n",task_no);
            os_shutdown();
            return 1;
        }
        task_no++;
    }

    if (util_mem) os_print_memory_map();
    os_run();
    if (util_perf) os_print_performance();
    os_shutdown();
    return 0;
}
