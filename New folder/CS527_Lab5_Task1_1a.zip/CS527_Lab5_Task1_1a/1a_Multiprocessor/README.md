# CS527 Task 1a — Multiprocessor Extension

This version extends the simple multitasking design to **4 processor instances** (`NP=4`).
Each active task is mapped to a processor. If all processors are occupied, additional tasks enter
the waiting queue. The scheduler executes a fixed 10-instruction time slice on each active task.
When a task finishes, its processor is freed and a waiting task is loaded.

## Build
```powershell
.\build_windows.bat
```
Or:
```powershell
gcc -std=c11 -Wall -Wextra -pedantic main.c compiler.c processor.c memory.c os.c -o cs527_lab.exe
```

## Run
```powershell
.\cs527_lab.exe tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data
```

The fifth task should be placed in the waiting queue until a processor becomes free.
