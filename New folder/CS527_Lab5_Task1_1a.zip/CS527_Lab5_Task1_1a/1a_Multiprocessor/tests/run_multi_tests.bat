@echo off
cs527_lab.exe tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data tests\loop_sum.txt tests\loop_sum.data
