#include "os.h"
#include "processor.h"
#include "compiler.h"
#include "memory.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#endif
#ifdef _WIN32
#include <conio.h>
#else
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/select.h>
#endif

#define MAX_TASKS 32

typedef struct {
    int active;
    int pid;
    int proc_id;
    char program[256];
    char data[256];
} Task;

static Task tasks[MAX_TASKS];
static int next_pid = 1;
static unsigned char free_pages[NUM_PHYSICAL_PAGES];

static int getFreePage(void) {
    for (int i=1; i<NUM_PHYSICAL_PAGES; ++i) {
        if (!free_pages[i]) {
            free_pages[i]=1;
            return i;
        }
    }
    return -1;
}

static void free_task_memory(int proc_id) {
    for(int i=0;i<NUM_LOGICAL_PAGES;i++){
        int frame=processors[proc_id].page_table[i];
        if(frame>0 && frame<NUM_PHYSICAL_PAGES) free_pages[frame]=0;
        processors[proc_id].page_table[i]=0;
    }
}

static int count_data_bytes(const char *file) {
    FILE *f=fopen(file,"r"); if(!f) return -1;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1) { if(x>255){fclose(f);return -1;} n++; }
    fclose(f); return n;
}

static int load_bytes_to_pages(const char *file, int proc_id, int is_instruction) {
    FILE *f=fopen(file,"r");
    if(!f) {perror(file);return -1;}
    int max = is_instruction ? INST_LOGICAL_SIZE : DATA_LOGICAL_SIZE;
    int n=0; unsigned x;
    while(fscanf(f,"%x",&x)==1){
        if(n>=max || x>255){fclose(f);return -1;}
        int logical=n;
        int phys=getPhysicalAddress(proc_id,is_instruction,logical);
        if(phys<0){fclose(f);return -1;}
        physical_memory()[phys]=(unsigned char)x;
        n++;
    }
    fclose(f);
    return n;
}

static int write_data_file(const char *file, int proc_id) {
    int n = count_data_bytes(file);
    if (n < 0) return -1;
    FILE *out = fopen(file, "w");
    if (!out) { perror(file); return -1; }
    unsigned char *m = physical_memory();
    for (int i = 0; i < n; ++i) {
        int phys = getPhysicalAddress(proc_id, 0, i);
        if (phys < 0) { fclose(out); return -1; }
        fprintf(out, "%02X", m[phys]);
        if ((i + 1) % 4 == 0) fputc('\n', out);
        else fputc(' ', out);
    }
    if (n % 4) fputc('\n', out);
    fclose(out);
    return 0;
}

static int allocate_for_task(int proc_id, const char *program, const char *data) {
    int inst_bytes=count_data_bytes(program);
    int data_bytes=count_data_bytes(data);
    if(inst_bytes<0 || data_bytes<0) return -1;

    int inst_pages=(inst_bytes + PAGESIZE-1)/PAGESIZE;
    int data_pages=(data_bytes + PAGESIZE-1)/PAGESIZE;
    if(inst_pages > INST_LOGICAL_SIZE/PAGESIZE || data_pages > DATA_LOGICAL_SIZE/PAGESIZE) return -1;

    memset(processors[proc_id].page_table,0,sizeof(processors[proc_id].page_table));
    for(int i=0;i<inst_pages;i++){
        int frame=getFreePage();
        if(frame<0){ free_task_memory(proc_id); return -1; }
        processors[proc_id].page_table[i]=(unsigned char)frame;
    }
    for(int i=0;i<data_pages;i++){
        int frame=getFreePage(); if(frame<0){free_task_memory(proc_id);return -1;}
        processors[proc_id].page_table[INST_LOGICAL_SIZE/PAGESIZE+i]=(unsigned char)frame;
    }

    if(load_bytes_to_pages(program,proc_id,1)<0 ||
       load_bytes_to_pages(data,proc_id,0)<0){
        free_task_memory(proc_id); return -1;
    }
    return 0;
}

void os_init(void) {
    memset(tasks,0,sizeof(tasks));
    memset(free_pages,0,sizeof(free_pages));
    memory_reset();
    for(int p=0;p<NP;p++){
        memset(&processors[p],0,sizeof(processors[p]));
        processors[p].proc_id=p;
        snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/process%d.log",p);
    }
#ifdef _WIN32
    _mkdir("logs");
#else
    mkdir("logs", 0755);
#endif
}

int os_add_task(const char *program_file, const char *data_file) {
    int slot=-1;
    for(int i=0;i<NP;i++) if(!processors[i].used){slot=i;break;}

    int t=-1;
    for(int i=0;i<MAX_TASKS;i++) if(!tasks[i].active){t=i;break;}
    if(t<0) return -1;

    if(slot<0) {
        /* Four processors are busy: retain the task in the waiting queue.
           It will be loaded when a processor becomes free. */
        tasks[t].active=1;
        tasks[t].pid=next_pid++;
        tasks[t].proc_id=-1;
        strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
        strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);
        printf("PID %d placed in waiting queue.\n",tasks[t].pid);
        return tasks[t].pid;
    }

    tasks[t].active=1;
    tasks[t].pid=next_pid++;
    tasks[t].proc_id=slot;
    strncpy(tasks[t].program,program_file,sizeof(tasks[t].program)-1);
    strncpy(tasks[t].data,data_file,sizeof(tasks[t].data)-1);

    processors[slot].used=1;
    processors[slot].proc_id=slot;
    if(allocate_for_task(slot,program_file,data_file)!=0){
        processors[slot].used=0; tasks[t].active=0; return -1;
    }
    snprintf(processors[slot].log_file,sizeof(processors[slot].log_file),"logs/pid%d.log",tasks[t].pid);
    processor_reset(slot);
    printf("Loaded PID %d on processor %d.\n",tasks[t].pid,slot);
    return tasks[t].pid;
}

static int active_count(void) {
    int n=0;
    for(int i=0;i<MAX_TASKS;i++) if(tasks[i].active)n++;
    return n;
}

static void release_finished(void) {
    for(int i=0;i<MAX_TASKS;i++){
        if(tasks[i].active && tasks[i].proc_id>=0){
            int p=tasks[i].proc_id;
            if(processors[p].finished){
                printf("PID %d finished on processor %d.\n",tasks[i].pid,p);
                write_data_file(tasks[i].data,p);
                free_task_memory(p);
                processors[p].used=0;
                tasks[i].active=0;
            }
        }
    }

    /* Fill newly free processors from the waiting queue. */
    for(int p=0;p<NP;p++){
        if(processors[p].used) continue;
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id==-1){
                tasks[i].proc_id=p;
                processors[p].used=1;
                if(allocate_for_task(p,tasks[i].program,tasks[i].data)!=0){
                    tasks[i].active=0; processors[p].used=0;
                    continue;
                }
                snprintf(processors[p].log_file,sizeof(processors[p].log_file),"logs/pid%d.log",tasks[i].pid);
                processor_reset(p);
                printf("Loaded waiting PID %d on processor %d.\n",tasks[i].pid,p);
                break;
            }
        }
    }
}

void os_run(void) {
    while(active_count()>0){
        for(int i=0;i<MAX_TASKS;i++){
            if(tasks[i].active && tasks[i].proc_id>=0){
                process_instructions(tasks[i].proc_id,10);
            }
        }
        release_finished();
    }
}

static void submit_shell_line(const char *line, int *serial) {
    if (strcmp(line, "exit") == 0) return;
    char program[256], data[256];
    if (sscanf(line, "%255s %255s", program, data) == 2) {
        char pbyte[256], dbyte[256];
        snprintf(pbyte, sizeof(pbyte), "shell_%d.program.byte", *serial);
        snprintf(dbyte, sizeof(dbyte), "shell_%d.data.byte", (*serial)++);
        if (compile_program(program, pbyte) == 0 && copy_data_file(data, dbyte) == 0)
            os_add_task(pbyte, dbyte);
    } else if (line[0] != '\0') {
        printf("\nUsage: <program.txt|program.byte> <data.byte>\n");
    }
}

void os_shell(void) {
    char line[512];
    int len = 0, serial = 0, exit_requested = 0;

#ifndef _WIN32
    struct termios oldt, raw;
    int have_tty = isatty(STDIN_FILENO);
    if (have_tty && tcgetattr(STDIN_FILENO, &oldt) == 0) {
        raw = oldt;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    }
#else
    int have_tty = 1;
#endif

    printf("$ "); fflush(stdout);
    while (!exit_requested) {
        /* One scheduler time slice, then poll the shell. */
        int any = active_count();
        if (any > 0) {
            for (int i = 0; i < MAX_TASKS; ++i)
                if (tasks[i].active && tasks[i].proc_id >= 0)
                    process_instructions(tasks[i].proc_id, 10);
            release_finished();
        }

#ifndef _WIN32
        fd_set set;
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        struct timeval tv = {0, 0};
        int ready = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
        if (ready > 0 && FD_ISSET(STDIN_FILENO, &set)) {
            char ch;
            while (read(STDIN_FILENO, &ch, 1) == 1) {
                if (ch == '\r' || ch == '\n') {
                    line[len] = '\0';
                    if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                    submit_shell_line(line, &serial);
                    len = 0;
                    printf("\n$ "); fflush(stdout);
                } else if (ch == 127 || ch == '\b') {
                    if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
                } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                    line[len++] = ch;
                    putchar(ch); fflush(stdout);
                }
            }
        }
#else
        while (_kbhit()) {
            int ch = _getch();
            if (ch == '\r' || ch == '\n') {
                line[len] = '\0';
                if (strcmp(line, "exit") == 0) { exit_requested = 1; break; }
                submit_shell_line(line, &serial);
                len = 0;
                printf("\n$ "); fflush(stdout);
            } else if (ch == 8) {
                if (len > 0) { --len; fputs("\b \b", stdout); fflush(stdout); }
            } else if (len < (int)sizeof(line) - 1 && ch >= 32 && ch <= 126) {
                line[len++] = (char)ch;
                putchar(ch); fflush(stdout);
            }
        }
#endif

        if (!have_tty && active_count() == 0) {
            /* For redirected stdin, fall back to blocking line input. */
            if (fgets(line, sizeof(line), stdin) == NULL) break;
            line[strcspn(line, "\r\n")] = '\0';
            if (strcmp(line, "exit") == 0) break;
            submit_shell_line(line, &serial);
            printf("$ "); fflush(stdout);
        }

        if (active_count() == 0 && !have_tty) break;
    }

#ifndef _WIN32
    if (have_tty) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
    /* After 'exit', the shell stops accepting new tasks; existing tasks continue. */
    os_run();
    putchar('\n');
}

void os_shutdown(void) {
    for(int i=0;i<NP;i++){
        if(processors[i].used) free_task_memory(i);
        processors[i].used=0;
    }
}
