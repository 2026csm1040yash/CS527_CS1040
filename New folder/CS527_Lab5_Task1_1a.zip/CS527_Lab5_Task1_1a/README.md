# CS527 — Task 1 and Task 1a

This package contains both requested architectures:

1. **Single processor with multiple tasks using context save/retrieve**.
2. **1a. Multiprocessor extension**, using four processor instances.

The source basis is the cumulative CS527 mini-computer implementation. See the README in each
folder for build/run commands and the included tests.
