# CS527 Lab 5 - Task 5
## Utilities on top of the existing system

This extension adds utilities to inspect the running simulator without replacing the existing OS, paging, multiprocessor, compiler, processor, or memory implementation.

### Utilities

`--utils` prints a short utility help menu.

`--memory-map` prints the physical-memory page map for loaded processes, including each process page-table frame, instruction frames, data frames, and currently free frames. The page table is stored in physical memory, consistent with Task 3.

`--performance` prints per-PID performance counters collected during execution:
- instructions executed
- memory reads
- memory writes
- scheduler time slices
- processor ID

`--all-utils` enables both views.

### Build - Linux
```bash
make
```

### Build - Windows / MinGW
```powershell
.\build_windows.bat
```

### Examples
```bash
./cs527_lab --utils
./cs527_lab --memory-map tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
./cs527_lab --performance tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
./cs527_lab --all-utils tests/util_test.txt tests/util_test.data tests/util_test2.txt tests/util_test2.data
```

### Relation to the lab specification
The lab specifies an OS layer, scheduler, task IDs/PIDs, processor mapping, paging/page tables and physical frames. Task 5 adds user-facing diagnostic utilities on top of those existing structures; it does not change the core instruction semantics.
